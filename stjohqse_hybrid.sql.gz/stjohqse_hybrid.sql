-- MySQL dump 10.19  Distrib 10.3.38-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: stjohqse_hybrid
-- ------------------------------------------------------
-- Server version	10.3.38-MariaDB-log-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hm2_coins_transactions`
--

DROP TABLE IF EXISTS `hm2_coins_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_coins_transactions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `coin` varchar(200) NOT NULL DEFAULT '',
  `user_id` bigint(20) NOT NULL DEFAULT 0,
  `confirmations` int(11) NOT NULL DEFAULT 0,
  `txid` varchar(200) NOT NULL DEFAULT '',
  `wallet` varchar(200) NOT NULL DEFAULT '',
  `amount` decimal(20,10) NOT NULL DEFAULT 0.0000000000,
  `ctime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_coins_transactions`
--

LOCK TABLES `hm2_coins_transactions` WRITE;
/*!40000 ALTER TABLE `hm2_coins_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_coins_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_deposit_addresses`
--

DROP TABLE IF EXISTS `hm2_deposit_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_deposit_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT 0,
  `type_id` int(10) unsigned DEFAULT 0,
  `ec` int(10) unsigned DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `address` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `addr` (`address`(40))
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_deposit_addresses`
--

LOCK TABLES `hm2_deposit_addresses` WRITE;
/*!40000 ALTER TABLE `hm2_deposit_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_deposit_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_deposits`
--

DROP TABLE IF EXISTS `hm2_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_deposits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT 0,
  `type_id` bigint(20) NOT NULL DEFAULT 0,
  `deposit_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_pay_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('on','off') DEFAULT 'on',
  `q_pays` bigint(20) NOT NULL DEFAULT 0,
  `amount` double(12,6) NOT NULL DEFAULT 0.000000,
  `actual_amount` double(12,6) NOT NULL DEFAULT 0.000000,
  `ec` int(11) NOT NULL,
  `compound` float(10,2) DEFAULT NULL,
  `dde` datetime DEFAULT '1999-01-01 00:00:00',
  `unit_amount` decimal(20,10) NOT NULL DEFAULT 1.0000000000,
  `bonus_flag` tinyint(1) NOT NULL DEFAULT 0,
  `init_amount` decimal(20,10) NOT NULL DEFAULT 0.0000000000,
  PRIMARY KEY (`id`),
  KEY `hi1` (`user_id`),
  KEY `hi2` (`deposit_date`),
  KEY `hi3` (`status`),
  KEY `hi4` (`user_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_deposits`
--

LOCK TABLES `hm2_deposits` WRITE;
/*!40000 ALTER TABLE `hm2_deposits` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_deposits` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`stjohqse_hybridroot`@`localhost`*/ /*!50003 TRIGGER after_deposits_insert AFTER INSERT ON hm2_deposits FOR EACH ROW BEGIN DECLARE f INT; SET f = (SELECT count(*) FROM hm2_user_balances WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'active_deposit'); IF (f > 0 AND NEW.status = 'on') THEN UPDATE hm2_user_balances SET amount = amount + NEW.actual_amount WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'active_deposit'; ELSE INSERT INTO hm2_user_balances SET amount = NEW.actual_amount, user_id = NEW.user_id, ec = NEW.ec, type = 'active_deposit'; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`stjohqse_hybridroot`@`localhost`*/ /*!50003 TRIGGER after_deposits_update AFTER UPDATE ON hm2_deposits FOR EACH ROW BEGIN DECLARE f INT; IF (OLD.status = 'on') THEN UPDATE hm2_user_balances SET amount = amount - OLD.actual_amount WHERE user_id = OLD.user_id AND ec = OLD.ec AND type = 'active_deposit'; END IF; IF (NEW.status = 'on') THEN SET f = (SELECT count(*) FROM hm2_user_balances WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'active_deposit'); IF (f > 0) THEN UPDATE hm2_user_balances SET amount = amount + NEW.actual_amount WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'active_deposit'; ELSE INSERT INTO hm2_user_balances SET amount = NEW.actual_amount, user_id = NEW.user_id, ec = NEW.ec, type = 'active_deposit'; END IF; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`stjohqse_hybridroot`@`localhost`*/ /*!50003 TRIGGER before_deposits_delete BEFORE DELETE ON hm2_deposits FOR EACH ROW BEGIN UPDATE hm2_user_balances SET amount = amount - OLD.actual_amount WHERE user_id = OLD.user_id AND ec = OLD.ec AND type = 'active_deposit'; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `hm2_emails`
--

DROP TABLE IF EXISTS `hm2_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_emails` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `html` text DEFAULT NULL,
  `use_html` tinyint(1) unsigned DEFAULT 0,
  `status` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `use_presets` tinyint(1) DEFAULT 0,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_emails`
--

LOCK TABLES `hm2_emails` WRITE;
/*!40000 ALTER TABLE `hm2_emails` DISABLE KEYS */;
INSERT INTO `hm2_emails` (`id`, `name`, `subject`, `text`, `html`, `use_html`, `status`, `use_presets`) VALUES ('registration','Registration Completetion','Registration Info','Hello #name#,\n\nThank you for registration on our site.\n\nYour login information:\n\nLogin: #username#\nPassword: #password#\n\nYou can login here: #site_url#\n\nContact us immediately if you did not authorize this registration.\n\nThank you.','',0,1,1),('confirm_registration','Registration Confirmation','Confirm your registration','Hello #name#,\n\nThank you for registering in our program\nPlease confirm your registration or ignore this message.\n\nCopy and paste this link to your browser:\n#site_url#/?a=confirm_registration&c=#confirm_string#\n\nThank you.\n#site_name#','',0,1,1),('forgot_password','Password Reminder','The password you requested','Hello #name#,\r\n\r\nSomeone (most likely you) requested your username and password from the IP #ip#.\r\nYour password has been changed!!!\r\n\r\nYou can log into our account with:\r\n\r\nUsername: #username#\r\nPassword: #password#\r\n\r\nHope that helps.','',0,1,1),('forgot_password_confirm','Password Reminder Confirmation','Password request confirmation','Hello #name#,\n\nPlease confirm your reqest for password reset.\n\nCopy and paste this link to your browser:\n#site_url#/?a=forgot_password&action=confirm&c=#confirm_string#\n\nThank you.\n#site_name#','',0,1,1),('bonus','Bonus Notification','Bonus Notification','Hello #name#,\r\n\r\nYou received a bonus: $#amount#\r\nYou can check your statistics here:\r\n#site_url#\r\n\r\nGood luck.','',0,1,1),('penalty','Penalty Notification','Penalty Notification','Hello #name#,\r\n\r\nYour account has been charged for $#amount#\r\nYou can check your statistics here:\r\n#site_url#\r\n\r\nGood luck.','',0,1,1),('change_account','Account Change Notification','Account Change Notification','Hello #name#,\r\n\r\nYour account data has been changed from ip #ip#\r\n\r\n\r\nNew information:\r\n\r\nPassword: #password#\r\nE-mail address: #email#\r\n\r\nContact us immediately if you did not authorize this change.\r\n\r\nThank you.','',0,1,1),('withdraw_request_user_notification','User Withdrawal Request Notification','Withdrawal Request has been sent','Hello #name#,\n\n\nYou have requested to withdraw $#amount#.\nRequest IP address is #ip#.\n\n\nThank you.\n#site_name#\n#site_url#','',0,1,1),('withdraw_request_admin_notification','Administrator Withdrawal Request Notification','Withdrawal Request has been sent','User #username# requested to withdraw $#amount# from IP #ip#.','',0,1,0),('withdraw_user_notification','User Withdrawal Notification','Withdrawal has been sent','Hello #name#.\n\n$#amount# has been successfully sent to your #currency# account #account#.\nTransaction batch is #batch#.\n\n#site_name#\n#site_url#','',0,1,1),('withdraw_admin_notification','Administrator Withdrawal Notification','Withdrawal has been sent','User #username# received $#amount# to #currency# account #account#. Batch is #batch#.','',0,1,0),('deposit_admin_notification','Administrator Deposit Notification','A deposit has been processed','User #username# deposit $#amount# #currency# to #plan#.\n\nAccount: #account#\nBatch: #batch#\nCompound: #compound#%.\nReferrers fee: $#ref_sum#','',0,1,0),('deposit_user_notification','Deposit User Notification','Payment received','Dear #name# (#username#)\r\n\r\nWe have successfully received your deposit $#amount# #currency# to #plan#.\r\n\r\nYour Account: #account#\r\nBatch: #batch#\r\nCompound: #compound#%.\r\n\r\n\r\nThank you.\r\n#site_name#\r\n#site_url#','',0,1,1),('exchange_admin_notification','Exchange Admin Notification','Currency Exchange Processed','User #username# has exchanged $#amount_from# #currency_from# to $#amount_to# #currency_to#.','',0,0,0),('exchange_user_notification','Exchange User Notification','Currency Exchange Completed','Dear #name# (#username#).\r\n\r\nYou have successfully exchanged $#amount_from# #currency_from# to $#amount_to# #currency_to#.\r\n\r\nThank you.\r\n#site_name#\r\n#site_url#','',0,0,1),('brute_force_activation','Account Activation after Brute Force','#site_name# - Your account activation code.','Someone from IP #ip# has entered a password for your account \"#username#\" incorrectly #max_tries# times. System locked your accout until you activate it.\n\nClick here to activate your account :\n\n#site_url#?a=activate&code=#activation_code#\n\nThank you.\n#site_name#','',0,1,1),('direct_signup_notification','Direct Referral Signup','You have a new direct signup on #site_name#','Dear #name# (#username#)\n\nYou have a new direct signup on #site_name#\nUser: #ref_username#\nName: #ref_name#\nE-mail: #ref_email#\n\nThank you.','',0,1,1),('referral_commision_notification','Referral Comission Notification','#site_name# Referral Comission','Dear #name# (#username#)\n\nYou have received a referral comission of $#amount# #currency# from the #ref_name# (#ref_username#) deposit.\n\nThank you.','',0,1,1),('pending_deposit_admin_notification','Deposit Request Admin Notification','Deposit Request Notification','User #username# save deposit $#amount# of #currency# to #plan#.\n\n#fields#','',0,1,0),('deposit_approved_admin_notification','Deposit Approved Admin Notification','Deposit has been approved','Deposit has been approved:\n\nUser: #username# (#name#)\nAmount: $#amount# of #currency#\nPlan: #plan#\nDate: #deposit_date#\n#fields#','',0,1,0),('deposit_approved_user_notification','Deposit Approved User Notification','Deposit has been approved','Dear #name#\n\nYour deposit has been approved:\n\nAmount: $#amount# of #currency#\nPlan: #plan#\n#fields#','',0,1,1),('account_update_confirmation','Account Update Confirmation','Account Update Confirmation','Dear #name# (#username#),\n\nSomeone from IP address #ip# (most likely you) is trying to change your account data.\n\nTo confirm these changes please use this Confirmation Code:\n#confirmation_code#\n\nThank you.\n#site_name#\n#site_url#','',0,1,1),('acsent_user','Send pin to user','Pin code','Hello #name#.\n\nSomeone tried login your account\nip: #ip#\nbrowser: #browser#\n\nPin code for entering your account is: #NEWPIN#\n\nThis code will be expired in 15 minutes.\n\n\n#site_name#\n#site_url#',NULL,0,1,1),('transaction_code_recovery','Transaction code recovery','Transaction code','Hello #name#.\n\nYour transaction code is : #transaction_code#\n\n\n#site_name#\n#site_url#',NULL,0,1,1),('tell_a_friend','Tell a friend','Friend invited you','Hello #name_invited#.\n\nYour friend #username# invited you\n\n#referal_link#\n\n\n#site_name#\n#site_url#',NULL,0,1,1),('deposit_account_admin_notification','Administrator Deposit Notification (from account balance)','A deposit has been processed','User #username# deposit $#amount# #currency# from account balance to #plan#.\n\nAccount: #account#\nBatch: #batch#\nCompound: #compound#%.\nReferrers fee: $#ref_sum#',NULL,0,1,0),('user_deposit_expired','Deposit expired to user','#site_name# . Deposit expired','Hello #name#.\n\nDeposit you made #deposit_date# has been expired.\nDeposit amount: $#deposit_amount#\nYour login: #username#.\n\n\n#site_name#\n#site_url#',NULL,0,0,1),('2fa_disabled_notification','2FA Disable User Notification','2FA Disabled','Hello #username#.\n\nTwo Factor Auth is disabled for your account by your request.\n\n\n#site_name#\n#site_url#',NULL,0,1,1),('2fa_enabled_notification','2FA Enable User Notification','2FA Enabled','Hello #username#.\n\nTwo Factor Auth is enabled for your account by your request.\n\n\n#site_name#\n#site_url#',NULL,0,1,1);
/*!40000 ALTER TABLE `hm2_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_exchange_rates`
--

DROP TABLE IF EXISTS `hm2_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_exchange_rates` (
  `sfrom` int(10) unsigned DEFAULT NULL,
  `sto` int(10) unsigned DEFAULT NULL,
  `percent` float(10,2) DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_exchange_rates`
--

LOCK TABLES `hm2_exchange_rates` WRITE;
/*!40000 ALTER TABLE `hm2_exchange_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_fchk`
--

DROP TABLE IF EXISTS `hm2_fchk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_fchk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) NOT NULL DEFAULT '',
  `key` varchar(50) NOT NULL DEFAULT '',
  `tdate` datetime NOT NULL,
  `inform` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_fchk`
--

LOCK TABLES `hm2_fchk` WRITE;
/*!40000 ALTER TABLE `hm2_fchk` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_fchk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_groups`
--

DROP TABLE IF EXISTS `hm2_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` text DEFAULT NULL,
  `fields` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_groups`
--

LOCK TABLES `hm2_groups` WRITE;
/*!40000 ALTER TABLE `hm2_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_history`
--

DROP TABLE IF EXISTS `hm2_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT 0,
  `amount` float(15,6) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text NOT NULL,
  `actual_amount` float(15,6) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `str` varchar(40) NOT NULL DEFAULT '',
  `ec` int(11) NOT NULL,
  `deposit_id` bigint(20) NOT NULL DEFAULT 0,
  `confirm_delete` varchar(20) NOT NULL DEFAULT '',
  `hidden_batch` varchar(200) NOT NULL DEFAULT '',
  `rate` decimal(20,10) NOT NULL DEFAULT 1.0000000000,
  `batch` varchar(200) NOT NULL DEFAULT '',
  `stype` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hi1` (`type`),
  KEY `hi2` (`user_id`,`type`),
  KEY `hi3` (`user_id`,`type`,`date`),
  KEY `hi4` (`type`,`ec`),
  KEY `hi5` (`date`,`deposit_id`),
  KEY `hi6` (`date`,`type`),
  KEY `hi7` (`date`,`type`,`deposit_id`),
  KEY `d2` (`deposit_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_history`
--

LOCK TABLES `hm2_history` WRITE;
/*!40000 ALTER TABLE `hm2_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`stjohqse_hybridroot`@`localhost`*/ /*!50003 TRIGGER after_history_insert AFTER INSERT ON hm2_history FOR EACH ROW BEGIN DECLARE f INT; SET f = (SELECT count(*) FROM hm2_user_balances WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'balance'); IF (f > 0) THEN UPDATE hm2_user_balances SET amount = amount + NEW.actual_amount WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'balance'; ELSE INSERT INTO hm2_user_balances SET amount = NEW.actual_amount, user_id = NEW.user_id, ec = NEW.ec, type = 'balance'; END IF; SET f = (SELECT count(*) FROM hm2_user_balances WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = NEW.type); IF (f > 0) THEN UPDATE hm2_user_balances SET amount = amount + NEW.actual_amount WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = NEW.type; ELSE INSERT INTO hm2_user_balances SET amount = NEW.actual_amount, user_id = NEW.user_id, ec = NEW.ec, type = NEW.type; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`stjohqse_hybridroot`@`localhost`*/ /*!50003 TRIGGER after_history_update AFTER UPDATE ON hm2_history FOR EACH ROW BEGIN DECLARE f INT; UPDATE hm2_user_balances SET amount = amount - OLD.actual_amount WHERE user_id = OLD.user_id AND ec = OLD.ec AND type = 'balance'; SET f = (SELECT count(*) FROM hm2_user_balances WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'balance'); IF (f > 0) THEN UPDATE hm2_user_balances SET amount = amount + NEW.actual_amount WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = 'balance'; ELSE INSERT INTO hm2_user_balances SET amount = NEW.actual_amount, user_id = NEW.user_id, ec = NEW.ec, type = 'balance'; END IF; UPDATE hm2_user_balances SET amount = amount - OLD.actual_amount WHERE user_id = OLD.user_id AND ec = OLD.ec AND type = OLD.type; SET f = (SELECT count(*) FROM hm2_user_balances WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = NEW.type); IF (f > 0) THEN UPDATE hm2_user_balances SET amount = amount + NEW.actual_amount WHERE user_id = NEW.user_id AND ec = NEW.ec AND type = NEW.type; ELSE INSERT INTO hm2_user_balances SET amount = NEW.actual_amount, user_id = NEW.user_id, ec = NEW.ec, type = NEW.type; END IF; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`stjohqse_hybridroot`@`localhost`*/ /*!50003 TRIGGER before_history_delete BEFORE DELETE ON hm2_history FOR EACH ROW BEGIN UPDATE hm2_user_balances SET amount = amount - OLD.actual_amount WHERE user_id = OLD.user_id AND ec = OLD.ec AND type = 'balance'; UPDATE hm2_user_balances SET amount = amount - OLD.actual_amount WHERE user_id = OLD.user_id AND ec = OLD.ec AND type = OLD.type; END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `hm2_history_descriptions`
--

DROP TABLE IF EXISTS `hm2_history_descriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_history_descriptions` (
  `type_id` bigint(20) NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_history_descriptions`
--

LOCK TABLES `hm2_history_descriptions` WRITE;
/*!40000 ALTER TABLE `hm2_history_descriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_history_descriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_holidays`
--

DROP TABLE IF EXISTS `hm2_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hd` date DEFAULT NULL,
  `hdescription` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_holidays`
--

LOCK TABLES `hm2_holidays` WRITE;
/*!40000 ALTER TABLE `hm2_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_in_out_fees`
--

DROP TABLE IF EXISTS `hm2_in_out_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_in_out_fees` (
  `ec` int(10) unsigned NOT NULL DEFAULT 0,
  `in_percent` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `out_percent` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `in_add_amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_add_amount` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `in_fee_min` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_fee_min` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `in_fee_max` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_fee_max` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `in_amount_min` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_amount_min` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `in_amount_max` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_amount_max` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_amount_min_auto` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `out_amount_max_auto` decimal(20,8) NOT NULL DEFAULT 0.00000000
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_in_out_fees`
--

LOCK TABLES `hm2_in_out_fees` WRITE;
/*!40000 ALTER TABLE `hm2_in_out_fees` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_in_out_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_news`
--

DROP TABLE IF EXISTS `hm2_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_news` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `small_text` text DEFAULT NULL,
  `full_text` text DEFAULT NULL,
  `lang` varchar(255) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_news`
--

LOCK TABLES `hm2_news` WRITE;
/*!40000 ALTER TABLE `hm2_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_online`
--

DROP TABLE IF EXISTS `hm2_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_online` (
  `ip` varchar(50) DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `d2` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_online`
--

LOCK TABLES `hm2_online` WRITE;
/*!40000 ALTER TABLE `hm2_online` DISABLE KEYS */;
INSERT INTO `hm2_online` (`ip`, `date`) VALUES ('154.28.188.199','2020-12-08 23:51:04');
/*!40000 ALTER TABLE `hm2_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_pay_errors`
--

DROP TABLE IF EXISTS `hm2_pay_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_pay_errors` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `txt` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_pay_errors`
--

LOCK TABLES `hm2_pay_errors` WRITE;
/*!40000 ALTER TABLE `hm2_pay_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_pay_errors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_pay_settings`
--

DROP TABLE IF EXISTS `hm2_pay_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_pay_settings` (
  `n` varchar(200) NOT NULL DEFAULT '',
  `v` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_pay_settings`
--

LOCK TABLES `hm2_pay_settings` WRITE;
/*!40000 ALTER TABLE `hm2_pay_settings` DISABLE KEYS */;
INSERT INTO `hm2_pay_settings` (`n`, `v`) VALUES ('settings_31','690810045e513f01777c5d7537504b067f542951222706530d0d5c06035452766a7771070801010121052f7461032d047e0f75530c7d047720014b0f5f03390b0e1d59640e5b594d26787f2a58312a497e79005c7751767253793e595e71715d771d5a77090a460769541b5c0f154a59207b03077c034173692600497859074c207d3b2d5f7a335c7e542c70712f5a2c0c7c020600026213601a07'),('settings_22','695410515e0e3c5277765d2137024b017f03290a0c7606040d555c5203554f755277105078540757170a2b2544053e567e562f0f5f7005240a515f01720e2b50221d03640a5b024e27780b2a7931284978795a5c377f3b727f792e597071734071255a160a7a0601566212586065116e301510161b4d'),('settings_39','6902100d5e053c0277265d7c37014b027f012954222606560d075c0e030f52736a7771500806015021532f2661032d567e0f750e0c7d042020554b015f0f77570e1d59640e5b464e1c78602a7d3139495579025c7a5138726a7907597871725d5b1d49772c0a46077f542a5c081559590b7b020775031965121b74'),('settings_11','6902100d5e053c0277265d7c37014b027f012954222606560d075c0e030f52736a7771500806015021532f2661032d567e0f750e0c7d042020554b015f0f77570e1d59640e5b464e1c78602a7d3139495579025c7a5138726a7907597871725d5b1d49772c0a46077f542a5c081559590b7b020775031965121b74'),('settings_18','695510045e023f0677755d2437034b047f572907227106030d075c000355527d6a7171020801015021542f7761092d567e0575510c74042120044b555f5571040e1d59640e5b024d1c786f2a4b3130496b79685c125128727f7974590571725d5b1d49772c0a05077f542a5c0b1547591d7b69070b0342735726714908594904197d022d797a7307526e3f60573c44360c69586e79672a5b0e0b03007400101664690f');
/*!40000 ALTER TABLE `hm2_pay_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_pending_deposits`
--

DROP TABLE IF EXISTS `hm2_pending_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_pending_deposits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ec` bigint(20) unsigned DEFAULT NULL,
  `fields` text DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `amount` float(12,6) NOT NULL DEFAULT 0.000000,
  `type_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('new','problem','processed') NOT NULL DEFAULT 'new',
  `compound` double(10,5) NOT NULL DEFAULT 0.00000,
  PRIMARY KEY (`id`),
  KEY `hi1` (`user_id`,`status`,`ec`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_pending_deposits`
--

LOCK TABLES `hm2_pending_deposits` WRITE;
/*!40000 ALTER TABLE `hm2_pending_deposits` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_pending_deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_plans`
--

DROP TABLE IF EXISTS `hm2_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_plans` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `min_deposit` float(12,6) DEFAULT NULL,
  `max_deposit` float(12,6) DEFAULT NULL,
  `percent` float(10,2) DEFAULT NULL,
  `status` enum('on','off') DEFAULT NULL,
  `parent` bigint(20) NOT NULL DEFAULT 0,
  `ext_id` bigint(20) NOT NULL DEFAULT 0,
  `bonus_percent` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_plans`
--

LOCK TABLES `hm2_plans` WRITE;
/*!40000 ALTER TABLE `hm2_plans` DISABLE KEYS */;
INSERT INTO `hm2_plans` (`id`, `name`, `description`, `min_deposit`, `max_deposit`, `percent`, `status`, `parent`, `ext_id`, `bonus_percent`) VALUES (1,'Plan 1',NULL,0.000000,100.000000,2.20,NULL,1,0,NULL),(2,'Plan 2',NULL,101.000000,1000.000000,2.30,NULL,1,0,NULL),(3,'Plan 3',NULL,1001.000000,0.000000,2.40,NULL,1,0,NULL),(4,'Plan 1',NULL,10.000000,100.000000,3.20,NULL,2,0,NULL),(5,'Plan 2',NULL,101.000000,1000.000000,3.30,NULL,2,0,NULL),(6,'Plan 3',NULL,1001.000000,5000.000000,3.40,NULL,2,0,NULL),(7,'Plan 1',NULL,10.000000,100.000000,10.00,NULL,3,0,NULL),(8,'Plan 2',NULL,101.000000,1000.000000,20.00,NULL,3,0,NULL),(9,'Plan 3',NULL,1001.000000,0.000000,50.00,NULL,3,0,NULL);
/*!40000 ALTER TABLE `hm2_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_processings`
--

DROP TABLE IF EXISTS `hm2_processings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_processings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `infofields` text DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `description` text NOT NULL,
  `verify` tinyint(1) NOT NULL DEFAULT 0,
  `lang` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1006 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_processings`
--

LOCK TABLES `hm2_processings` WRITE;
/*!40000 ALTER TABLE `hm2_processings` DISABLE KEYS */;
INSERT INTO `hm2_processings` (`id`, `name`, `infofields`, `status`, `description`, `verify`, `lang`) VALUES (999,'Bank Wire','a:2:{s:7:\"deposit\";a:3:{i:1;s:9:\"Bank Name\";i:2;s:12:\"Account Name\";i:3;s:15:\"Payment Details\";}s:8:\"withdraw\";a:0:{}}',0,'Send your bank wires here:<br>\r\nBeneficiary\'s Bank Name: <b>Your Bank Name</b><br>\r\nBeneficiary\'s Bank SWIFT code: <b>Your Bank SWIFT code</b><br>\r\nBeneficiary\'s Bank Address: <b>Your Bank address</b><br>\r\nBeneficiary Account: <b>Your Account</b><br>\r\nBeneficiary Name: <b>Your Name</b><br>\r\n\r\nCorrespondent Bank Name: <b>Your Bank Name</b><br>\r\nCorrespondent Bank Address: <b>Your Bank Address</b><br>\r\nCorrespondent Bank codes: <b>Your Bank codes</b><br>\r\nABA: <b>Your ABA</b><br>',0,''),(1000,'e-Bullion','a:2:{s:7:\"deposit\";a:2:{i:1;s:13:\"Payer Account\";i:2;s:14:\"Transaction ID\";}s:8:\"withdraw\";a:0:{}}',0,'Please send your payments to this account: <b>Your e-Bullion account</b>',0,''),(1001,'NetPay','a:2:{s:7:\"deposit\";a:2:{i:1;s:13:\"Payer Account\";i:2;s:14:\"Transaction ID\";}s:8:\"withdraw\";a:0:{}}',0,'Send your funds to account: <b>Your NetPay account</b>',0,''),(1002,'GoldMoney','a:2:{s:7:\"deposit\";a:2:{i:1;s:13:\"Payer Account\";i:2;s:14:\"Transaction ID\";}s:8:\"withdraw\";a:0:{}}',0,'Send your fund to account: <b>your GoldMoney account</b>',0,''),(1003,'MoneyBookers','a:2:{s:7:\"deposit\";a:2:{i:1;s:13:\"Payer Account\";i:2;s:14:\"Transaction ID\";}s:8:\"withdraw\";a:0:{}}',0,'Send your funds to account: <b>your MoneyBookers account</b>',0,''),(1004,'Pecunix','a:2:{s:7:\"deposit\";a:2:{i:1;s:19:\"Your e-mail address\";i:2;s:16:\"Reference Number\";}s:8:\"withdraw\";a:0:{}}',0,'Send your funds to account: <b>your Pecunix account</b>',0,''),(1005,'PicPay','a:2:{s:7:\"deposit\";a:2:{i:1;s:13:\"Payer Account\";i:2;s:14:\"Transaction ID\";}s:8:\"withdraw\";a:0:{}}',0,'Send your funds to account: <b>Your PicPay account</b>',0,'');
/*!40000 ALTER TABLE `hm2_processings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_referal`
--

DROP TABLE IF EXISTS `hm2_referal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_referal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` bigint(20) NOT NULL DEFAULT 0,
  `name` varchar(200) DEFAULT NULL,
  `from_value` decimal(20,10) DEFAULT NULL,
  `to_value` decimal(20,10) DEFAULT NULL,
  `percent` double(10,2) DEFAULT NULL,
  `percent_daily` double(10,2) DEFAULT NULL,
  `percent_weekly` double(10,2) DEFAULT NULL,
  `percent_monthly` double(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_referal`
--

LOCK TABLES `hm2_referal` WRITE;
/*!40000 ALTER TABLE `hm2_referal` DISABLE KEYS */;
INSERT INTO `hm2_referal` (`id`, `level`, `name`, `from_value`, `to_value`, `percent`, `percent_daily`, `percent_weekly`, `percent_monthly`) VALUES (1,1,'Level A',1.0000000000,2.0000000000,2.00,0.00,0.00,0.00),(2,1,'Level B',3.0000000000,5.0000000000,3.00,0.00,0.00,0.00),(3,1,'Level C',6.0000000000,10.0000000000,5.00,0.00,0.00,0.00),(4,1,'Level D',11.0000000000,20.0000000000,7.50,0.00,0.00,0.00),(5,1,'Level E',21.0000000000,0.0000000000,10.00,0.00,0.00,0.00);
/*!40000 ALTER TABLE `hm2_referal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_referal_stats`
--

DROP TABLE IF EXISTS `hm2_referal_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_referal_stats` (
  `date` date NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `income` bigint(20) NOT NULL,
  `reg` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_referal_stats`
--

LOCK TABLES `hm2_referal_stats` WRITE;
/*!40000 ALTER TABLE `hm2_referal_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_referal_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_savelog`
--

DROP TABLE IF EXISTS `hm2_savelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_savelog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `log_text` text DEFAULT NULL,
  `log_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_savelog`
--

LOCK TABLES `hm2_savelog` WRITE;
/*!40000 ALTER TABLE `hm2_savelog` DISABLE KEYS */;
INSERT INTO `hm2_savelog` (`id`, `log_text`, `log_date`) VALUES (1,'[[[EQHiRIpMr/kMqfoFH5B0gED7wBxeuOlwyqsJi5n90nQljeG6eFzTI6WjiuerWOHW9aq2kJpkIZf1JMJSDoi6nEpJpZ3cKAauYmOqFsQi3VcmMNy79kt28Dx2KsQk6tEs+pZfT5EqnX7q6wCAcDbxvjJPVtM9BI4+FdI3x2PZk4A=]]][[[RA75AqcsuIj8Nlu+z1+19GxA6+Fif4FXt0CuQ9IM4W/Zmq8Ln8kfurTVac5zYvMCGIOLy/VEqL+I/YFK0ovy18QcjgR484SzCxfjZZlL+5tsBY+BzOCSx7jXbcfYtmSF0kU2pMN9ozRo9n4VC+SCRdb3W+NtTe8dQrcjmzrfoF0=]]][[[Eiid2K6jTnz3uMaUcJbNTEyl+FLIR3Ys4oJYA43O2AnDh2uUqy1QA29EYyFWADWgFr3SRXPMBPH/71osMknpYrrzWv7g0bbYQ8TEOYI4z4f6Mg4ZxgPeIM0edVY7ae0hMY4WUVtq6b7st3EAaZvj8tr0sESPgRa6nbEpV+MTKys=]]][[[HB55oBjhjQRkqATitZQps6UCQGiOAIyBMMt426bnaxM8W6b6TA+HgecD3HdLjHRww/yQxjkl6sgQUP21K+vcJIhH0gjGzPZ4f6GqyYDWJ9H3u4WPeKGg6P8pY0VHv//MR0KZUA0s0Ynkw53Y47oy/Wgb07olPlu7vszWNTlAhlc=]]]','2020-12-07 11:07:58'),(2,'[[[cQ29xp+hZIcqHUN3JdXR6/5sMEQMFCgJwIA05i8colfl1ZrTOy1mvSUbY7Hrl861hphkw5Xf5Lizv4L05FrUNRTaP654nk9j+XRF0pnx2lNKCUtJJGFOW0ZlWlMW4T8wRZK4SYL+Ym4QRDGT4mVCOFDsWMmVu7rk6Bws3aQlppg=]]]','2020-12-07 11:08:00'),(3,'[[[JG7TYg6P11jUmzJEPfAaZnCJLi7xXcCwShnX9vdrT1DQ/duKRyp1M2sgVMSDxeMa4tLIggWfFCKDAjWt73ad/FIDlMYUqpUs7nLYZ7DTozrPY10DYogR3XgLDGhsVwjXfYPzM44DFvn5q0mMdDfOnwRBIwf4Adz+Gi5uuD/SYi0=]]]','2020-12-07 11:08:01'),(4,'[[[Jd4nwaZzPHBVMzOqw9eV0FeXCleZ6CpNyVHJ4yR8bPfAcdzbrdBzXGm9ESRjSXzO+lrsm1VAw5yBHRjuAED5GZtnJqNErJaZYVMxpRS5rTvYFf6OsRPki1Wlm7a7+/KR+ICtRsT3zAeIz4JdEM9/sna/f7kFR6ysMrREG4huCZQ=]]]','2020-12-07 11:08:01'),(5,'[[[LeGDpjR7V5dyGHNV7/KIV0AmSnbyVcF4UEUuMp6mV8zp6txN8i6xmIPVb4EiCgbRrY0Qim5pDMmaM8EWtG5fB5naqtn+0p0ocfaZs//JaJ2kxOushwoOaHPTbR3zhvBuF1QBIgem7V5wOKLa7UHDtnqkmFgz/SHZyTV1/VYGPPY=]]]','2020-12-07 11:10:04'),(6,'[[[dVNQXGNeannGSKTqKkRX5N+cJixZeJoZk2HKl/eOZy0vsuSTPUULXUGgIlWIPd8my7+2/GD5GEfpWUJjoFeKvJtLbJ1zYx1sVIvH39MPu3Jl2CCiAKud/faG7mlxxUU9mpHZrpNRSjh3jnqcoihuL+ToQU3Vqmm4mWYi3mb+JNo=]]]','2020-12-07 11:10:05'),(7,'[[[EPvJG+4CXzVow+13jd3lVY8aGKf5qxPFSM76dWhqWOMeYZHsdSpdhrLKiEhG9uoZ/DXD8QLZlxLqlZIzyV8i6s7At32QJ1h6aO/gEXIbjnzYXYaGr6lobruLJbb2R8s2yb+LL5Qhv2hh2JtCP1LHtIipQwFgwoJnyc0sVE8UJcM=]]]','2020-12-07 11:10:05'),(8,'[[[aSydJQgc9bmOaCaITJjqLJApxoxhc3YUo3YQxDBhj0KdwfAIc3joFaw4quH89J65w+tiZUJ0PxxCEpPsjs11q/TJeM1D1NfMofbsIstOaiW9E3m+XJGnq6PSQ1idMK3XfkMOLd9x9ZfOgPk8OKE9eb2f2EoyBSsqrV7IoBzzxaA=]]]','2020-12-07 11:10:08'),(9,'[[[E/ThXKazMAFPNw4Fp/LBKVKgficpRxuQmpqyldfYgt6yx/My+i98wXCcud5iNp30b0L6lPvBwUaTg3SpBcnC9T0uA6wuA76baW4pL+Z6THdBtvboJnzJc/ntaGAIjyPdGEPgftLS0iQHskXXWk+PmJyUKq3uMDHCHsPmyw4xNJY=]]]','2020-12-07 11:10:08'),(10,'[[[njHOC5exX7jOAXZJBzJxumtDPr22mbfCMvX3k2+JEZQR0TbyGlI9fR5/J7HNSaKcEM2fp/mVHryzaUgrUGm9ZaNIvQ+a8RKi+EI9Cth9BSdRn3KL6nOhu5LFKqwrlli/t9yAcS+74mdBhl2+JwyfMVyzPi77WZhkfUlmMkL6DEA=]]]','2020-12-07 11:10:09'),(11,'[[[rgYB/mKUY5jtw1T5c6cmGy8T2s0NxOvAGJo/Ze8G9T8jDxT4M0vBPs7/YiqyUmp35vXWa/U4+e3oD07ZPtoYkou7NbwT4i5/ABa2/o8WSa7xuEGqug+ssWYf2SEru+yhYZ/kNLjjzNarjQ3S0owRpD0nviz+IqttVg8buPgK/Lc=]]]','2020-12-07 11:10:15'),(12,'[[[tN2MzLKEsxPfC3ApmguV7xYipBud0CReYieT+y98KSonRvE492vSCc3Pul9P072k5bjDfCDubc4Ot0lkTRUPYIychgaI75qS8HAC7xGUGgmupQGajlRtCPYP86eQY6jKD0N5ml2zGEigwUEyEesGtpTvUCDAGNJWQ5bGpBeSbbU=]]]','2020-12-07 11:10:16'),(13,'[[[GumStq8Kcg4LIb1yJ/OrOrsQKzVZookS5XZbj4UOGXsmffMO/eObgvveCTAoZLiqaXmpy+gguw6LFoS7o7Q6VZd88RWZNjlRWfPQcTyzTKneS9xo/eskkOthigmYAZkA5iG+ROqj29hdhiacdLz2rCg7+6vAMh6hGBPHECcPiZc=]]]','2020-12-07 11:10:16'),(14,'[[[fhpTwTd6V8RiL16XA2Avr0sQKaauoy27ixx7CNZbXKXNUs+aInI/SsTkovPvYqe0dQlG3P+QbVxpIVlbvXjb15mPOedSjH3eDXMPnJcEXfEjTxH9c03jhSOaKA1fTL3zFsi4bZrOXMBcuhDOZaLmfHetPedseJ5wFg8PgjbZRmA=]]]','2020-12-07 12:18:33'),(15,'[[[ojuR0IXLrgBATPgiSs1OmHuZCRIzRRMlBn3i7lNKJNnfEOy0MlHPjIq6RELVrbRTeMl/AWU0FI35PgV9a7zcXEoaxwZJnDfx1oFVlmst4RirV47ED5xyHiJatlOEsnk5l+vuUA7waBKUdVVPEe1jiaqVMZcNqP4dgF3As4fpyj4=]]]','2020-12-07 12:18:34'),(16,'[[[PqLItlU7BATM3a1BP9KPM9JMUTNQiv1aS5+lJDanFUc7y3VtEe409W35aKXWT5BMGMtojHKv7SMjb7t5PRTQrBhqJYK5uIMSY7xD/S8dU/Hddf/AyBRZAopP+hDH/EUsikeXxTvk1bxnpQ7RgM57/N9Y+MRLGhBMhM99ZSM4s10=]]]','2020-12-07 12:18:34'),(17,'[[[OgJRmiWgPtj3UltHgcOQWcxk9IlX/8ZnwrucVVze1hQpyMDpMTBQZ8gaoFGjc22YsSWbvu0P5dUQucXf7JZS/cnjdU/pfbd4WfC6m1cJu2Cw1UbC4viZr9/bxQPSbQe64T1eDbInSyEAhvOz3V5S+P8X9VenmXSFow1ztgfdEeM=]]]','2020-12-07 12:19:56'),(18,'[[[Ix5mbBBMVuFm+wxp0AvbhHOp0XF1lDP1hK48jqqgLZSWjyJmMIRzNTdUjNwWrepjfFiDvSyBlAOjHtWeKJ7V4SICtrgl3ORJxyJrJuh1aThTEXUMKWIvX76QXhGCSWrwUyBPuLoYsmSzob8FqgSTZeLYS1PPbiWnX9GrmT7Bczs=]]]','2020-12-07 12:19:56'),(19,'[[[pBgWFwYfVQGyFKBYDdebXz2KmNp/g2oIESsQNyWJPvWdrCrjUQx94JjznrT23pOLQ2k5ejePQohQRPbcR42ywhjHT0XpZwHuxJbP4Jj7iLGwX3wEr9GP93AnF/KTAmSi2Gquc6/Vb9yni65MhdSnjNt+4c/QJBamfjRwWwg38m0=]]]','2020-12-07 12:19:56'),(20,'[[[LNUG3oFwjD0PQh5O2U2zjxEPl48RpopdMRcVGLuNdty8XH9YSsRU4x1pl3+7DTMsqo8WiEDjOxtcaoYJtgx3Xma3KfQ9q9VtxX+jhpRqyHZ/1AHYYP01jL/7WMa9bdlcVIVElMXeQ6SN9aA/2lhfhDshERwQOE8E7Yxd8i5I8OE=]]][[[a+O62y2PcpAhzdEd1OpwmrQZj/AxctCzid4TPeAN7s5R0iRhSEKgnAkX7mWGNqFNjBsfgrANdX+i2SbtEwbr0eR5HH3IBxQcEE/EUmcx6B0t1B1UlkMpeLbkWp+ldIDJYfK7X+hfZvL/yUnoPTMjQiMLQJkKrNpr6uaSwTfWlHs=]]][[[ZKA56EgcxO1h0QrBqKpKyXbdaPcGMLlcaKueLY2lOxiwpLn3d48tDmcoB3kKX2vs9OYM3x2r1+G6GahWZEtnCma/acVv6SgI108gxLVttdpEDzmZY9+VrsuKzA+mTqvZGMrMPhf3hh6syWYTcbJu5brIfO3bBX7FNPg+WGQwA+k=]]][[[ljl667wro1jFJVDcVjXjmx0a/IhWkUQPwFUDY1iiYpGO0eFQ0hbCGIioJu5LfO1eR4BnM+4gwwNzNja+8g/sNs9Rr8i9bx496B5IA3Aq82PiRMiq8g9m5rcsygsYFF03e+wnql5iDzaoD2FwmU/GqwPyl68/St/gU9cqyHpyVVw=]]]','2020-12-07 12:20:25'),(21,'[[[E26u9vM8onwic1kY4tvzcwnBTt988bdG5ys2Y0qJtbQmuCH8ldG4IpsfEswsE6O48Yqb9yh0BfSgOOccMsqMsC0sipoRZyMa/sf+lr5d29zHoZ8hdSR6jIE5DXDuhYlnmdh1lqM+g7eU/+khucqau9uR/8qVHsypjLp57zJIllE=]]]','2020-12-07 12:20:27'),(22,'[[[KtnQaD1ul3xGTSgRWnbl9bx1uQeuBRsCgqIWB5EDdVlV4H5ecuvGnaXjwqQItT+JP9t6967D4T8qW4M+r5vfnIJtJN73v7pAzAso9CPhTZBQNF1/tKKqCeAleUpbrHeb9Ah4n9BrU8Pv/vsPLy2ftiQAlCQ5HQNXYkG+uPkjo54=]]]','2020-12-07 12:20:28'),(23,'[[[jZebwq6414umAOYVOTH9FPhxQP1YExZBBOLEsZkgE6sKlozCRmJM6zOo/uKVu9D+HRBkOIedNLXYMu1POH9Fuj+/9/Nj0REyy0yi0LVpDnqfIgd5Cfh1qaMafJVQweJk6hV9vKuuWmazKSwPpkEo0yiLkRDWC/VPhgAsInSfowM=]]]','2020-12-07 12:20:28'),(24,'[[[TjealsvDtgmW+/oQmKTHxeR6WMSU+PLgFkwBgXuKHsB1QXlgQ4nD2ZTqTsOV/gaykfVbCGDPb9eW1BjgwqcuHLcQ48W4PZo8AmXUHyzEwi/BDf0tRhg4uiRQbbm4H1GGSt7VnsELSkL5sb3lZcisTVuqu46hpmCaAD0IvJupiZ8=]]]','2020-12-07 12:20:37'),(25,'[[[Bpb+HQIzoFzg8aKQIRjZTFsSgeHf5cA7mxqI08NXy3TY9aMCj26BdpqZodyjEYXGgLUUNAM0ppdTaHOMwun+hAX403OXrd4wvbGSg5ijq7xlW1tlGibWRwENXbw4u8uDlt+HMMfJqAV1Czw2XG6BwZXp+zul9Ch+aQbljTZaG3w=]]]','2020-12-07 12:20:37'),(26,'[[[U/+g8jb7rTK3kQsWIhd6N6gW2q5P89xVhs9joHgLqhEiM/ydca8Aye6pd/5GrqrOoTvDqk77RBwnhaTvi80gEGVKDlItVezuwHsbmpRXRNOo+XWSUP6TDW679p43Kbt2IBon5uCeXraEAUyGd8MVgoQhAOBes8l3eVmhGkNFfDU=]]]','2020-12-07 12:20:38'),(27,'[[[gDjwIxgTXaRJ+x0cZRP3TYGSeQ4cJ/PH0jK2STCBn8MkEihpfrbC9TCFNb+SJlQ9PrFye1rfMtv0r7QCNdSTd4u394aOFS3mNcPVYSrdNcVwpYioEouGvP4W40YNu05ftENHJOiDeTOQYIiP5VbOcOO9hatnUKykMH8kBxzfgqQ=]]]','2020-12-07 12:20:56'),(28,'[[[EIQIzAPbjyD7+zjyxOqXz8rpHvxaI/E3am6ketB7B7Zvm8qy9XZohJAxK+0b6EeJ5IvKxK9Y5LStUjmT1lmNl/LCjJQNs0isQphb2xEvzYJPUmWrTfILl3mlbUToMmutOC6IDQFz7QkGGpHvKnJhc/nrc/PXzZnVtFEkU0+qBeI=]]]','2020-12-07 12:20:56'),(29,'[[[JAAIEddi1ohMtY4noSw4r99VFxhv3tzE1hto8MZ4FWCXKelbLRyHqz3EnSgvYGnsO8zrUkoVHY9S+F5bFYxF2ZCL81SJ7Ys2axY+Ew6KoGFz4/K2PcyrjuuzSUuFP0AsED4G9GXCsC16c0oC4MgsBHDGl2rU5NgmGbrVmee3BhA=]]]','2020-12-07 12:20:57'),(30,'[[[Brv+giYIoA1/LNX3vd/4AEVGsjcy670rlWrQQUge+snxteC5azsV2+LvYh2m31ouOF0Yhw5RehuEh6LO5EU4s4PQkSlrbJpGGkCeCozl3oSNZDhJXD6ykE2gRh5M2dN+7ypF83N6F7RpttteHyIB3oUFQt8wmhl7Y0FdN6DwOOE=]]]','2020-12-07 12:21:04'),(31,'[[[CVfOFL3eAkwL2DnDFq7abInGExW9WE/zdS9YR1wk2XOOoBOxZInyySEJmBhiQizkPHz3ZoAsuZBYwcyLe0G4wNypakj0i5jh2GpmQ725WXTtmQD0JzoGfOWvFQanG5VMJkSi7caHvBXErBag1V8KMIWp9bcNkR4qeQZMsxddwss=]]]','2020-12-07 12:21:05'),(32,'[[[p/6mofhRPSVER7CJC/83YqxhN6eHf2p+VGMm64lmdwqG4r1B1M2AFHgDQxIHhUM0UtpJhIOdSpn/5eJc2HyPvUL45NyG8NOaiLw4Luz/IYQJrJSmCnG9ZkreeeDcADjvL0/xss5WgzUxx+nYAl8XTVBwsRuvIYdUhsPLsLTEZsU=]]]','2020-12-07 12:21:05'),(33,'[[[ik6HioSNGMd2eEaqSWLqi/tMSXZwA9sUbZvKYbX4E3PtNJ0FlNwQjPe5FyuRTeb/GmBWMr5QQt0mUTAsE/i+QoexKnsVncB5Z69ok5OE6lHbOBgViLBkSzl8PB7MqBJt7PwxUG6UaR23LZr5F9UYCwhfnzjW47/M5zUHbOwjR1g=]]]','2020-12-07 12:21:20'),(34,'[[[Q9oVFN0BQxFg1PWyanHbmRr4Ds19ZSN7LwB8WwBUaLKTEqsNNZhKky+N7NCM1HxiJfcehIEdNxsQjZgY/XmU7K8AH1A42S1H6UL1HdLQGP8EzTY5lueiPQoaCC7Fb4Yi6YcZVhVltQFUW0+cU6mgoWRUyp8pZeyrUTtcds7ZbPU=]]]','2020-12-07 12:21:20'),(35,'[[[N4QvVoBHYlDhN4whfU5Z+NSQzd197RKXhtLZI4T3vdC0uKieP0oACfEslAQfHxoCqVmq2+XW12pnqyVnzmYUMazDnlGVc3jpNNvZkA0SKF7UXt6zl64SSnNYn+9OwnxvhzCnSNf/1u1XO6owc/bwZyRali8TLN/tbiP0ZQHxXqE=]]]','2020-12-07 12:21:20'),(36,'[[[MYFFhW21O3uT/AJdeLR4sRAvFwC7nCMaiDZHKp8xDCi4icH9tfIIDBghmoB3LwMWFfk9uFzb21mphLWGreNLfGku8KnuzaRobmozuhkfwb7smWr4jwSZKBPeHTGh2BCO8FgDVXz2xz0ZlfhLfO0ddLyOqfXpZ0kUknbPeR2t6N4=]]]','2020-12-07 12:21:22'),(37,'[[[ZvooRKJWXEvNsk7mwP9T/mFYD7u9BtQ0OWR+9R9uGEFggeHr73jQ4R1KFPa+Ivt+x+u7BhLVanWWrkr+TGscCr1TKDmOjw79R+FIbuw2073sEVyGVqM0v3iuHWpBfGx2VETWZuSXow6Bf7oNHIPlViqAbqQkhfa5JTPaDqepQe4=]]]','2020-12-07 12:21:22'),(38,'[[[O+HLPYMCm7TkJMY0vekxrEKgCswxwa90XMQfb7CHhzbjoXqgfyFTD4tHOJA4mD0/ykRCdeuGDl2lLpRnRm2CGbnr70xmNpNu+t2zppTr/eoXt5U7dzgqMnFN97P/mIbZu8AT2YTOrLaM/Vbf0E2Ackaia/NTAS4OvoCM4RBMNk8=]]]','2020-12-07 12:21:22'),(39,'[[[rmyOsf3CsBcNh+S2jDr0vzurhzf9KUn1K9YgNC8os3r/9EpWOtJpUIQfX/YUWaxw7QtpDl4BECxsT7X8SgX22TOXEJn7/iecmo9cl0UPnxgdaE4+ESsB4hA3eEY8PDYyo4o4HYcrPRb6dKSKrazcUebHEF+evMKRgjlW/MpQzJM=]]][[[cO7P9y9PW/hJTTY/TbVMFqhvQLtsWC61HlxUZVd5vCV/K6bgzwtJ5HutUxs9ZHwB34XLHsbir+nD6ZpDlglXFSyz9DBZptfbSXnJENms9sMv5tyT0mPrUJuRgoeIM9MfkuZTbf04bSab13tMv+yjHO0YzdEU0xXW/arTgxheDbU=]]]','2020-12-07 12:21:22'),(40,'[[[U0UiHeSeGeAjUEvsguiapYvZwv0ks8pIDcv/Q2jNM5egmyCFubFwPSDRJWfDfxE/6dDqXJWBWJJgaStosHw49xD5OI19HZCqhOjlYlxRkNu8rX9RpY6GOhmk/ueDTaJmoPFZ3iwRjPLZtsAbGQ19XBdLg7HkUdBNzf2mWoGV5ts=]]][[[ZR9sWexocJ0r3uoDwDT9EyTYg6PeJvhIE8ER7y634r/n0RPkFV6xWK4ZQvtbeSzGO0AM2f6M7IBaS0C0fVkZ0JtFhiBCF/+i2OKtD+pfMweI8H0BcrZHrOdDCT42zFzw5ksANGlCbaIiM2UXOZ1llqGrIunPg8ex6oEl/m5+I/Y=]]]','2020-12-07 12:21:23'),(41,'[[[MHAv/FyDUHQlk7EfyUBcyRpBkchMPmgMZuuBdS+AGQJxyy5+EiZTPRRDgnWA0qGjuEYcnDyXMphQwswSM9S6pDvi80CND8/67ABuxJPf3j01eDEsAscUlU5feNf0FWMg30Hdn13SqobCHAhph7SduSK3vUS0hyskh+DxKXLuWSk=]]][[[i3GOS8DxS0UTdOTptHcvlCz7oWBkGNlv3nJA/Fmz2n9nzNlKY4M9a0QwzGqGFnaseHHC9ggQ5LLhKS2wyS+YcfLX6+L7KnVqoFPkYytC/7xjeEaIS9MFpk+xacWsEGMKwkHeBN34MvFHvgKbRoHVW4Hgq2rIymtbWcNLUbCULpI=]]]','2020-12-07 12:21:24'),(42,'[[[QvkRFoCavZdJ79PuZe5iXctKKUzFrDukaLqtDKzFexE3YHhg/We474aqjfRDSAvA6ebg9G88vLSTAB8alwgSG8Gs7ZaS2ouLEzXN65EkyI6XuxOv32BNpIpPuhdYJAKWGNAb1K0wmNsOPSEYk2RC3GyQU8Kp1jhkv/0jK5fcGXU=]]]','2020-12-07 12:21:48'),(43,'[[[HYLgsNiQpeVgpYKA0iOQbToPZV55+WFOdhTz4sW8Z/FeGz1/PtgBzAs0tOWEYs5QW+2QN+e+QY5yuR8XEM+IkBnV9vCCvCNGWcVW+EykyswMAXhKOTuq4pgB++QetE031XpNG8iMZRaFXePY9PCU91azX7RG+e3fB9re6G56kXQ=]]]','2020-12-07 12:21:48'),(44,'[[[RQjZ1fzMmWlrTu1AHu7POrZj4XWdQYE9IyLAne9sAxoHwHLaJkXrIDMgQFMEoJlnNhBO++x6I62dlunbTU9b31z/cZYa2D0bqMsRbnDNTvCp/fxYt/kaXvy7br31AMUOrxUO3FHLu3ZXdEHgKqpY9T3QSn+qZk7TANcQUp5QwfA=]]]','2020-12-07 12:21:48'),(45,'[[[iSn9M4q9Jx3wSItzqUD5SzmTcgs0XCr8BbfwSeBE/8Bx2jHQbI2TARLaY12PheFdcSaOFstW7cXwmuQMpoNX/S0P2ha9zMzuug9IMZdMHpEik9J3O4VXCMjOWPddzzIJf2nUL/l8pgETB+uJ4DeafSaxOPIhIPJuOeSB513/RhU=]]]','2020-12-07 12:22:27'),(46,'[[[ihHtCxKSsIC086J6HN3pxJlvvSwaE1AHeqiWHB/bxQN6yQkuMhajikcUVEvcuUWhrqqm9NOudJj5BISV5K+BbucsvX8cVJriAwTV42xW4pAspcPbf/XTjQzG3dKRLWUawBU+NCiIFTV8Jpr3oLaJ7yR8amA1c9KkPhtKodHUFDA=]]]','2020-12-07 12:22:28'),(47,'[[[hqQge3fUSWg8j/jlEeU1plsx+BhJ2ATxmwBpxW6NjA2hn5qmnX9SUpHtv05mwSO+D/kQx48EwvxOwUcD+NrqT8utWryRdTItKD/x6TXjQcA1hytTKM8rFgQWxbVWHUHZrUTG3/QxSEoHAjjRYaxVMdZ8g+WB/o+lm9BMInNQXmg=]]]','2020-12-07 12:22:28'),(48,'[[[JRZy2q4xNUvxgGXd5p9cn0WL0HaK0H/CrbqJRI8g7KIG4JR/a3aODyIsE/O5qAS0Og9F3X5XYVv7/MAf77mwcd5y2ZKCQMiB91R8L4zBDX0f2LAt4TW2F6OekpLPEyiZSp8b/WgiCBbkJXtvLNJluGQxgHgYOQFlxoIpWnKba5w=]]][[[h9OWlfI+9qn0faix66eNRXsQ//lonBzXRRYwWfwabdcCA4o/N1/OTOIrFqbtq0+8mRlmdIfuu1kc3t/NY3e8FOktOkvw3CNgKJ7TvDN1zYKVNO5SY3y21aHQ8j+U3Lhr74yb+PW0ZDjcsSdP16zii+P/f6dFy/wYsiYMI83TO9M=]]][[[nlJzWiXgCbOUVqvyAK8fQJsm2vodgZUJLHEE6Z7M4Pb8CblRXd1aUBZ2cBxOo+ZFY6TN/66mwjxLOHof89LXVjfkz6wzIkbc1ETIjk/4ZwsFfH7ZxNRJjjcdp2v/H0vt0GLaXoyKiAXiNYG9wuM+FMeAN4Lq24bqsoSptLrfdaE=]]][[[EgxbFP1OemYjIBixZJ3iJfRkxqiSzv15g/pt2oRkKCoX93XUNQH9hD15uPKJh6HOZeafqFbneLz4IFBzO304xDTLsCeq/fUctEd6Oi+bkWzQOwui9gaR9rveDz3ztwrsGjyK4QFXGhOjflhrvkX+NO71xh/01Z1FsgmZ9xFOxGU=]]]','2020-12-07 19:32:56'),(49,'[[[j6xdrUGaiOUB6VOtGlkWsOPAUV8g7O8dcWSYKc4SmJ5yoI4wgGjQVOgU6effnbvUSNT0xKgYWsjLGxlC9P/BG4KaBWwDfHt8dOzEJYY05B8hROfvD93NVGjJgT79Gc+3FpiGDTELueC0iRYVgedTpQwVqvUL0xtr4Ek+PGZ5k28=]]]','2020-12-07 19:32:58'),(50,'[[[ciFDRMv4w7KJsg54GamaHZKCYdiSU0K/g4fBf4EAnSE0gl81ugmfGK+jiH65GkAtzdRDQUpdUwpIvGk6sajm5h4zL9EOC5nUArnNLxMAIg8OTl44kHRRMePIC5MG0sh87r9VOj2CN+Rtfw6Gh7Z+ed8Rfx66OmPR+R+iMoAWrsA=]]]','2020-12-07 19:32:58'),(51,'[[[Cn5sigS+aEsNsN8qvLd/Ym9nRynnaCjFSdiaviJMJYOf2XuKxPMIM+mfOT2t/08vutxpzpkkRbLsmf4RFPHODwONtW+G3qDVRB4KdmfZZe0Za47kv0w4BDsXHuylnOHd0ujSZFDurowrmpDklqIUfHJ/+bvuBftoa+PlgTAS9l8=]]]','2020-12-07 19:32:58'),(52,'[[[jA+Vl9wWsiNexx6c0BXfOXWc9f754QJKCVntBKp3KrXiki9vkLKqBJ+l0xkd+Bb9vkiuoyCitOGvIiPsDnBPs9qnTm/7PyXZvq2SPN9h/qFbVWJntYRc/a/RD3ZP1iyR/dTJ1blCRy6UspniPcAIE0mhQkEL+KXQIiA34XQeiWY=]]]','2020-12-07 19:33:34'),(53,'[[[oSeD2hOw//kEw9rnb/NLyRSPxhXEAJ+v8bVskc48DDVesFS0/g+ZJwEp43ISFLDt3JUyNTsDhqsE9zrNFjuJwQ3BfNafi09QwHnFCJXnRJaa8Jfkjx6TsvDEcy3dt2m1BqmHffLSDNSRVeQD2fX35p/Db0/X7VKQoZp8Lq898yE=]]]','2020-12-07 19:33:34'),(54,'[[[Bla1hI60av4bxii25B6hZV/VmCVWUCUz18L1gZxSDG1isPUDGzgd+s4IA45q5im6DGGUNWMzQNJNHgMAmqPTIDgNfB5RpBY1lr+iZDL5yS5rVzHoRFgS6yMyVnDN7arjRi1hWPQPu3RKhV0wMYIl+RR0ydGIO9eMMuriCRqI4sw=]]]','2020-12-07 19:33:35'),(55,'[[[tYUrtWlZoxIFVseEvbbVid1tJS50kSVNOh7cNoOBR4BaGoiT+bpMt+i3J0ZvfPW2X3vbDu40dELqhBKf52h9/CKgjsoqCWJXhhTggWaF0UTaJ0/uUciKWLqa+st2yRnXTXLGsM3C+RWiQ1N2Dku1AI0IKdyVUM1snGpEqisYkTU=]]]','2020-12-07 19:33:38'),(56,'[[[HIA3maOXUSmT0TV9vmvVlsHJ8kqAntZ2jde5VEwGXau3H+S2+9lkzHdKEuXxXpYvEcB40sm179MLnE/VQU/RZGBRDGe4FTu/gmr6SfLqoDs7th2LYeADFTlDFORkVeiqNDWWkzgT3JjkT0KnARLBH1UeIYDAYsNUqQhXlvroJxI=]]]','2020-12-07 19:33:38'),(57,'[[[pQIpQon8XSkbQTuF/7kcMhxuN0DXi5FNF5tk0ICk55GRmk60Tb5BQnO4LSCkNsW3zZnjFRET15Ivbkyo2eX3KcPQGY980Uw/1+jH2x/iY3qYbQ2hQT5c7AzaTQgZz2pwyR3/TohN8JyRBjmWJQYUQGYqbLDoIU6EczembF/S88s=]]]','2020-12-07 19:33:39'),(58,'[[[Iu1+WNxSt+YrPUhD4lB3dGH/Y7bNpgWulNEXroefLU+bIIGWSS22Xr0sBdVOASgfJlujs6MuK000PVTfjiWJljNGXPK9E+zRwEeC6u1ZUsZyCp2DBMQD39nwogJSj6hLIXQgU6I0ix65NWohXgI+Ir56cXKaeg5P1C5Fu5xmOYM=]]]','2020-12-07 19:33:48'),(59,'[[[lQftzgGDUZ7XK5tOxuTuFSGiqgxPZ8h8g+gwhHZi20UkiuWxL+0ibdSTjfxEVtsrHSKR7BFrB87lk4R80Z2sa1Q7Gd88NvuxH4txEfDIpkw817TLCm+v4kqzj4yf4292bneTmgc8F71XXrIlNnBbgHLvwYry6hj6P0qds9aWl/I=]]]','2020-12-07 19:33:48'),(60,'[[[S1irKubugLlyZ9pzdU8VsAZkJ9wdjasNjRfYupr3ZfyV44HFSCgyhWo2RdN0ct6IqthuQ8vzM3mIe+YEqqA/iy5ObX/YUbkDuNVb6qIhNF84oWOMZ16Bze/ewToZDZww4JMcPX4WME9Lja7eTNEj5fXU+hyz9f/9/hOALnird1k=]]]','2020-12-07 19:33:48'),(61,'[[[FxNQzub7tGX2Kgnh0CHYUWny+ADoldGbEzg5VFDX+2DLTp/oEHHoIgK27GuGBiw8B1sXiMJAJ5yvGDP+iRfgLHeyXTODU+Q4m8vT61WrvQUHMbfEXBgmMHCU0N7OFb/jkKmaVDYmwrn0ze4nnZ90VwJpP7d8/0qD2db9fffJhjI=]]]','2020-12-07 19:33:49'),(62,'[[[HTWfKfEvo0+n2/OlNT+WjhYCqSEFw+F1OxbWencpSiSwA/aHJ0Q6+f7HpL7sFgFpY9gUllzv2+TYOnok3tnVgkDKyWXeB5tR7V5TYhoxM8derulFPjFJ73klDPketgRMuMpxTImT/3LoNGaDOMrcOOyXFDjDPpB32/6sT1s34YY=]]]','2020-12-07 19:33:50'),(63,'[[[Fs48s/2gKkXxgHRsG09haE/u3vO2fcetNiQHpvaNOOPj9kg1eO4vv5VTSoLru8oFP0/wGft54YLyreLOB6bChWCHhBgw3jylIp+mVyhP1wTR0mbuFchVSCkx15luZQeTFMOgJCks7gTj0HIz51DSHoyUHWsu8WWcI/pM+kpeeXI=]]]','2020-12-07 19:33:50'),(64,'[[[fks+bPjLztkH9k5beDcwGlJzdcwiCk42waflkJg8QGadEs9z2qrT9HfN59nwIdLHAk5OKb2I6d0dSMrscpFA5R473mFl7uY+chSTJPietwu0cegl0BhucnUwtSZOV8SGTnzXXF63D/4j/K6ZroJ8zY0FNifIEIVUwumnCphL9OQ=]]]','2020-12-07 19:34:03'),(65,'[[[Gl55Ys1wasy8xe53GKQ1x/GNX+KgzX6gvTawlUAkkugBAJhNxUhtkAKExTAbxlJAzIyOS6LKaqEOyxmHJOHwhMxb22/JIgtP+TCxPA2O5lfI4hYnMcXXYu3G1QzWVhseNITwb6PYXfmlWMc73MgFKHCUPwY5Wr9u2ygLCCC5nGg=]]]','2020-12-07 19:34:03'),(66,'[[[FWSHS5nM+pxP3njBa2VJXynMQDyIEC+NLKk7D1gD8jxZuYEmmK+JWhOV+6u9CudYCLKrGInmOfX91KSNv3dCut9Hc9YKUtx79Of9e3bpA8LGNZ+WmHGTcMzMD2MFHJj/NsDTGhvJ+kFi3PIJok87djL9/QU9zQUUBmoXWbsrESQ=]]]','2020-12-07 19:34:04'),(67,'[[[g7hlB2SwqK2VhHZh43HmLea3yZUxu+WqtsMNrcG6gutia9h23MY6ZdKKfX9DNFWC8MxMbNWzkqxETMtYuCTFCTnDwt0Kw/sPlVxAwrbQ+WwgFwRhJSAG6H4OwAZklZ8LTfUaGYzIjcJv6Jm2KchaL+NKtmwCS4Oh5Xdp3I4bClM=]]]','2020-12-07 19:34:19'),(68,'[[[CZYBcAwQD/+2PKR/zPZpOmy3jTXZ6oqtJAWpiSU1RZw5iPr4xWKAM4E8MaXZwMZicGI1FUJUURXy3UzgiU8S4hQE4EdKeP0yLhTy6dgszW9x9Fsj/ZaXcciDWIEkfTS33jqLftt+rhHxD6PQtoaNaOYJv63+3jj13JUYaNqkqTc=]]]','2020-12-07 19:34:19'),(69,'[[[UZo0GORvWXUhktsOkDe2nTQU9GyHn8VTi8sdD6zDrX3vcBs7GlTH8O7lN+rQCHJgI/CS0HwbyAH2ew28PyHSDkob7PGrWTwpjwOAL2uey8XiAmto4sx5QQ2RRHB2Q3fnFD2OIvQaZDvle8tCB1/KT6gZUMDpQrYa21qoxYW1mGo=]]]','2020-12-07 19:34:20'),(70,'[[[IpUJLWE3pamzxhyhyevuu3IQOSw64RdBR47n0adqQg2glgkfZHKOfl4If6gm6GOE1mYj2qpZg0txzcss8c54WukvlLKXL3xcZBXp7yMOyn3I4rDSS5TwBSjpjUbecnyL8fr7jYu435+rg84OPBVZCRtPVVr9vT8+f0OZ0DiYvAg=]]]','2020-12-07 19:34:42'),(71,'[[[EftlOT9tQ57VQvIM6L0JZwDWMNpu5h7EnmZz82n4a9oIXCp+jCvZWmnRIByYo5ZIQUNpWuLCWHNbrtT5HCTvrdbU3w3B2MXT0AZ9vjlNSJ3g7o/qetH7Dwm5WBh06DJfhl0bwgx4vj1zJHMLJ7rJfVkCnPWwtbWzlkdRpRasBv0=]]]','2020-12-07 19:34:42'),(72,'[[[Rui5ReWFhEVbASzevd8mM5m3jhdn3DDlOOfxGkyX8Cz8yBBr2QfHe1KF/lN+oACZTTwTzqSCkwTw7auCs8W1PWC+2L7leGlUjYLt8jWTdHJHp+V7bDeHvvLgQRisfinU8uXwfBmaeyIwyglNjI6e/c9EqgRK0tKTmDSUsU6SwkM=]]]','2020-12-07 19:34:43'),(73,'[[[C84dhsXqNyu/45fSLQepmIxLbBDsdqW5tpZiGmrUF3GWoGwGu2rQEBUVQDVeWbN6Ljl92gF6Ca6hjvaJO91q7i7bP8zNrdQ6qAcvuFEAq9Mdz+nBQfIMBPY2ZRJurSH3qWYF/afQVkyay/mEC0sUKyOm9ffUTSybhvIszpy/7pQ=]]]','2020-12-07 19:34:55'),(74,'[[[poYLz5Cgt491fG4yfW9h6PsA70JBkFBNltAMljNURpG2IFqLeZ9ncBvhNHV8yTvu+36NhvbF5cVQbTVw7hIeeTkjUdvFgJbJDqd+43I6x3XYg6C8Ik/EtwrxPLv59v79fc6oz8QCZjQswGTzNFhKHA9MJL0MHS6QIVksaD1f0BE=]]]','2020-12-07 19:34:55'),(75,'[[[R/b1PeBPi1CK7ocO8U2JPbmG+uIaQzpwFJxsRuBWGdVddMrjEuGJpjs+NI7D+0MQajZCVpNsQq7TycZ8sok0ZmlA3dw9H6qG0tz7sdmoLNcIcauv7kkemTWJZSV11LJhJBoi+MH8kL/PBiOH5BvgRC85XIyvVvjCW49nX6KYiqA=]]]','2020-12-07 19:34:56'),(76,'[[[bhsiOexu89onM9w4IufC0m8RiKaG+KQcjRBrdqlgVACgJ0rhFnlBgv2IJEmB9uO9uSJ8SCxgIn0g6iav24wVxNAR2GKPCCJKtbTL3rQKN5fVb3P37eMvnqaZ0+qpadTPcVNMleeQ8FQZ4VgooCP5ZlMdZtyXbi2d4HCmf7gtwJg=]]]','2020-12-07 19:35:02'),(77,'[[[ZFS50liLaSLedlIq4OU6DGATTCfLjLqxSoQgYCTBUTxB6MuBTCog47eX6dAeUfFSHULuZ4+09clZ7pJ/FiWGTR8OVlTIlsd16aMKrK0K/5DVCYFx49OZ4OGg0nTWm1//DH/s7PVhyABCqZWF+dNoo/o1v9QDscTHFh7p2wleoS8=]]]','2020-12-07 19:35:02'),(78,'[[[MSTnfBhDn6y6+iqJbDOpuwavDu1rPNvs4Ws6L9a9P+eh4upo2jmX0+lB3NeCSoxorODj5GOjPBlTQoYWxeATnNywfGnPxFqwimDWIkXQUErgI+l1opevJkakUETLqozcq5B6Wnae9YqeXUSTkYBT4jUBK5jcy06I7a/0desZxME=]]]','2020-12-07 19:35:02'),(79,'[[[UF9lGllX8P2w4k9vpGujLDmdoGmslGsjJ7VKz4Ncq8tXH+FRFB25h6yt6CbOxhHMWKFFN1yWBTmv+6fJ5HxK1aTQRKo673/Mk7uTtb2TOPDHW7Js/SkP4sSCO9bqCNoceGaVZoDIg7Ikm+maIuvaj5lR/rk+2o4ypsLjsRE6Iv4=]]]','2020-12-07 19:35:24'),(80,'[[[d/9kIDae9ImeBs/zHWC36/73gn3q1120JQXDoAMMnbui6dl+2XtGhqqlw6X1ctF5OhWxkYrjR5fykj2LzNgL0VstHsRdjpyK/wvrQtaz8k7vBVwqsYYfkQEplkvrrL16kk3oghzhVUgRsafq2HluJFdKUCLc89iZ3wn8uj9EGRI=]]]','2020-12-07 19:35:24'),(81,'[[[De246rUdvcElrTwXMCzkyQquN9LMBs6Nfr5FS824Tvj5gjK2Xh6ZhNbsObVhyVe2Cy65+E89+bQKyOeJgmRzNECHkvoknQ9qlAa2vGyb0RhTUELijN15jfco5AHa2S5oRZ/JqJAdxB8qXHlQVjbvto+buOsBJKsbvezQn+1JvSM=]]]','2020-12-07 19:35:25'),(82,'[[[SLe1FiQKkVGVewE9Ha6oCdBu59RBBK0tsV33ZiCxEP7mcGIIRuiRvGA5m2ohb/7Luhc9gR6/Quu5qMLiD50rKjqVSLBoIWy/3Z6fWHkPTsDoi9QJingRSLyeAwwZmGUa7U77PMLir1BsKKkWLUINtumTCZz+BA0aZEZ5mFQSZX0=]]]','2020-12-07 19:35:29'),(83,'[[[mnyXVEY3guYo/YqXvV5R5Pk20KQu2HvBZPxz7oUdWUbvrc8rEKzKSYOPd1YveVuMwZYvOtQz7wqDVNrIaSmqZIv8RgwSP4P4JEOnog5Y2WZBI4S53ded6zKRNhj1uyaPknOeOGGC7pVZcBR+FTQ3iJog02ukj0kdC3oW1Oi480o=]]]','2020-12-07 19:35:29'),(84,'[[[dBshpgqYDTiPU3zWZX8sVjRXTltfCm1uI9nRkuqVUsLB4lllpg0uXqnHmOcMJsHPmugAcexVg6D4CYjV4tXFAaIUcJBXikMVxD+vmqN6pBGyB44/nAVjn+zYIK2ytlS/jnXhBnNKlJ8//CJl4XOlk+oGdPRuGRXgIHEnvhSPMiU=]]]','2020-12-07 19:35:29'),(85,'[[[WJR9zd2AJSzlH622RReL35+dnFwF3mFSw/cOWM6/t0L5jnw6tUA2ymjag87T3cqu+mNPzCUXbx3r2IOu+9QpN9GZO4C9HW5XATQT2a/ekWeIwzdQHN5D48TGWHKvznG3o1Nu91i9kHJMbT3xlJIdC4xvMKFgHgzBfJOIA/Rc+lA=]]]','2020-12-07 19:35:33'),(86,'[[[Kk6rzDDlxrOAAFUhLh/wOl3zSBIDiLSrLq1oNSLv1BlFTLiHMx/Xbj/O3TiMVdWh/4rKhafwZm/l1INERVZVvGryX/fqr3s2pmMCDKJE4kYjK+1vuUpqEiAo2Xo+D8u4cJfax2hr6mXnEioQu2PCx8XfYObH/IMXRDRKFqUb7BI=]]]','2020-12-07 19:35:33'),(87,'[[[WGv2yobUUBDnumwwgC/bVrtXcV1MbH0OI82UlgdhEqYJeYNqC+tXSakBcxPp4DeAuJC+r1GKbCTUYONBXXAgTvTx/fmqPi3NJWoq3xDsufblnsor/C4UfkaDWnIFe9ixxIbsY9wgpa8g2efyJC6fkznk7vNRmM50pRSL5FPxe9k=]]]','2020-12-07 19:35:33'),(88,'[[[eEe2Fr2vTFUX3LwbdDQep5WUtEiYn9aIQ+kLtUN683KAXWCofxeQsu2VEYmY/SU3EQvNTbO4cOgwXoiNeajNk6OJuEj0UWZw9o2FP2U4EcSv9Ws6nowrX+GkLCA/6ZVuJTl8FyZRk0HWvz4qJ3Z+jysc5jeUnRdHhE7upNGeP9k=]]]','2020-12-07 19:35:37'),(89,'[[[IsV2KDjXAMmm3RLmuL0OtguMBDbbyh/qtIv1u2VOJEb6mCu28nj1ZW5BZPvsFPJ7yCTsRm+p3itmJMVPFt/1lhViuZIdZtDGEVXDTWJZCDkZotSmtmT8StRdO7aXioqrYgf1Nl2O0yE6T9ZAQD4L9PIaOhJML5hs/8ITRolawPA=]]]','2020-12-07 19:35:38'),(90,'[[[Wed3vnzRlanVNZ7ivXT5FmVYcCLj+DUs/LxGojChMEkqz6cwi8WIyANzjxVOlepuWWKiQhLsqHf/W8lvXRI8YuOFpMdVNNkpbg6qoCOJwDQwyAyflLHwG8dFEJF8TTJyS10b4mcS1Jt5/bp6kHeQjvoCclO1AxWm6Bs+g4V78x8=]]]','2020-12-07 19:35:38'),(91,'[[[fT+An1yFWDWBZgWtax5x18CsWKbab7RhbJAjcQGLRFAx2LV0qKoJnH0j79hVSWfsWEC6ovruX6xKm3u0CY4i4oVf6CLjwzoQgdlYwwnDOAVFKgP3QoNvTCP4hpYAQSFxe0FaJKpusileZ3/JTKl0xzS551ugU9EyCSzClMVSt+I=]]]','2020-12-07 19:35:46'),(92,'[[[M0WDwgQTHUZevL0SXXY9BkpqNlnB8VZ4xc9pvEwyxXA6nCoaT+depdsLd1o5zW3ap23s6lmYY1UdtE+EILCpnkhEVMFvHLWTikb795EZ3kHeVzDh9A2N/62W9OJ0uFjDtCaJa2XsogvDA4W31WBO5L8/GQEtsa4Xev+g+pb/tik=]]]','2020-12-07 19:35:46'),(93,'[[[RuI6iOUKw1yxYlw+IEP/v5ZYnqLgnegqMzBoQTXObwnJEWOGO6dTMSXl25uyE2F8F/i//EP0XB6cAZLpx3TWrWT/NNgD/4mvU0eAf/l47T5isdHQoquN1//VrAIjLD5WpshS5RXgcB/3mA3IqfrJj+PNLsL5ycx76DXYefqkQvI=]]]','2020-12-07 19:35:46'),(94,'[[[DCkqHwJ7dBescULw07Wc+j/HMTihqAjHXALJegDPN5nEaUhviyBuYzluIvpfr6I1p+ev/GfYS5NSDlBoNeqYzylCLgTYf4LIsMdj/cLQ7jyplIC6LbJwaX0rp+uqxUUl2Dii2PWSoUUfTigY/tT8nc5VPmTaMsZfS16JT7KBrSs=]]]','2020-12-07 19:35:51'),(95,'[[[Jt1UsLXxTZsnRDb136yJBArjJ5IXaLfnUi858OdHtN3glU5Z6dIJreop5uRR7Ca4ajma94ejXf5TJCIawkssM2v4yw2m8SZg4bQJLPrvb7/pid5+w/fLdrT+KS6eVmE6U14qc2Oxs6jJeBo7rK7XAvG6VYl6d0eRD7NHuoWPi7k=]]]','2020-12-07 19:35:52'),(96,'[[[cHCadSfqI2q8I4pLwWYz0pelNiJYg7sMNiUTHmxY/tGNEhGapHxdAx1ZNAj+oOqyZVCh2DSyApU2IHzyMs4yPs4zwl8io+d3nG6A8+0Fj/XzU5u9KWZcC+5KLJpSV+cZ45142sTp+bO/Xql/ANXZnqrXtJYD6XAhIh6q9s0cGzs=]]]','2020-12-07 19:35:52'),(97,'[[[ZjJKazwegYd2t1LXUvOJFW3qVskDUSv06C7MKSJXXuD7XzbVIhueowGEUD6G/i1AQ0NCA+NuDeq5fwa0mAk2QGD/KxMqR/5U4oT+Q7V62SAT9ACbQHNL+EpDhinc1MN3W78h9vgmnOZFNXzZquMTh50vj5WBOVowgp2s2PynrQ0=]]]','2020-12-07 19:35:57'),(98,'[[[YVoDsY3+3lvzrACXi8IE3RQuvX1Z9uqDHHdLzp6Z76KrX2yycYg+U5uHvNXsyQgZ0sh+HjVHgimbZa29YlQ6Fd6ccd8mpBjTITxDF4uTRgpbYhxwxGHN+8O3/5cEyKgEaEbrB82wDU/eZCzUMK9E6ZqgmB5l2Qp15+hMF6qYyGc=]]]','2020-12-07 19:35:58'),(99,'[[[EJIxPGVRLMhEyTE0xH7CLV3JFeo2RrShaN0yUSXal/I9u7xUw/TerMvGelBZG+wg6hGcl7iBM7H4xa/OEyzSugPOdghS7GodojrfqIMD62t2mWDbJuCEDu2uTYPFvXPaBl4Xyf38DMnOJZu5tss/bwOf3H+vtgu8gMPr6mlAKBA=]]]','2020-12-07 19:35:58'),(100,'[[[EjGeuG6/Q8dNzB0N74dlySkeYl0Gy/876yFWhI2tUnYPVr21jExYR5JYxw6BrtSdytcdt+lbr+LwMV8LCpK7CiQLtL4zpNq2v+d3xGxGkoMStFq89ICFLSv4/JsgR1ImVtMNKORtD4u8nNz2veoTKVVEwKmj+Yj1bMjpfuZJtDU=]]]','2020-12-07 19:36:02'),(101,'[[[MhvEF0h6cjxyCf4M+NIP/jHQZbZsA+EqmFOPH6YqfGB1JA5qJpbwe6Pu1SUBuTMty3o6YBDeT71J7U968k7TK24eieb6TfRKBYMxJ1EwF40jDn4UcKnTCVjht7Ko0djGpICBzLch6XxoSsUgoT+oUIBXgJjQ0DIpdI6wrEzmFOM=]]]','2020-12-07 19:36:03'),(102,'[[[N1qVeGs3bI41JMen6hKXuACsvO1MqGRT9ckqt72H7YbsiZmOkUt1XkCJUW98YIvCI+3h2Xrxw4lCHOBmnESXQmrIGbKRgR8bACcDh8DUacHWl9cNT/1g/Qh4pASMGBiOwYfcssbjZLjO/eH+cKLoFZ5+d4GGpRdqVrp64dWDwiI=]]]','2020-12-07 19:36:03'),(103,'[[[QpFsJ2WcVOklZAyL+UtTA7yA6Yty6qgyagiKQ6yhDmI0z6//lRaTv0/6LeZM6Y+AP7H0fXaaCzUpSuSg3pYgY8QuF9mZdu/52GA48zgraaBLtsqjw998dDYwvianhhKAXnpTp++flGZ147WXDrw2kiD98aRfXpBcJx0ea8hFPw0=]]]','2020-12-07 19:36:07'),(104,'[[[VYEBSTYabjWc0J9UwgbG/w5UWHQU5cpz9JtwStkgvdlG2KkksmXcMTNvO3Z3MmOFy1MvtOKhTxA6hirMlvyt0l5zr56vyT/6Kn3EEsWhbQTg6KFQiaYIidSPt+/pNae1/YJmrkvZtVUDbTet4xegk/qiCA6j2uf7QOHn1N0z5sE=]]]','2020-12-07 19:36:08'),(105,'[[[Prxzd85h6Rjjsyzqxak6KtTIik18VLWsD3+05VycKEB66AUMe6SOu7iLWUc9P+vuTHuSSZPsnSmpULaO8AjHzlTRR5QDEsnxpPzp57zreeh1iiMG8eqwWdiV5gjqgN0wigfJsexssTJLqxW5p+TZlz3JaxSOS8XaO7uQ73ZFxZ4=]]]','2020-12-07 19:36:08'),(106,'[[[h3QWDvspoUmTJj5TxNlILy1ZJ2eqNttPBwZ2CuV4H/byYalc3P8E6CIEcqo8qIiNJU/WpRIEinSWnQRLRr38AikJxDfh4+4zZYKGoC4+8N6iag4yftqnfPR5sQQEf4iODZnRBSZrUdQqfLIQdkVeqNjqTWGvUxULkJquBsOrcyY=]]]','2020-12-07 19:36:13'),(107,'[[[D6IcuWg8bHoibrG8xvE85wpOZfI2ZN6wcYPjMTTZCycXEHXwXeqsK115WL8+Z3pYNHgOHRPUtkXd2KZo6PM735N1CCAbUjKiv4tgSg2lH373VmFPUB15tZA8AOYHyaihg0LV0n/vNXnh19wXCjX8puKt6Ai1I7GDHlO3HjRhW6E=]]]','2020-12-07 19:36:13'),(108,'[[[ndUOmIlhaSk0NOEYcQhSkDRPxK5tSW/BvthP0PEAP76ZY5BJI+0v734wJVZFPEurcWDjjqJ3R7Mzm3GnaOMMH/NXwWI+yB3t+KyEyxHAHxJlYsKowsJOVJWIzW0drELyV48/OFv6+/CYey8DAd7BpT90++xtQVEGfZJn6xfC0iY=]]]','2020-12-07 19:36:13'),(109,'[[[s2950yEM0L9iKiTr8a1DaGUXzgJhPO3iJsinXbcsOEUN+Dja4ukDKJtbepGRs6TTZspA0gMV7fsDCc5yOJYj5uYJOSNNnS9f9hXDwlsX6c7tQAd3IxoVkxPjFyVBYgHYwVRr1JocWL8b6ymb3kO1iNFd9g0A8G79OF2PfdR483A=]]]','2020-12-07 19:36:15'),(110,'[[[h28rVrcjuVwtLvH7j7E0sL5Qwr1gb4X8B+KR1CbxTXDQQpfk8K4v/6563KUHZyV51uRWUl5k1SXlFO9u9m0n0HTlBI11rD2O0WK2tCBBSNdlS8kTWFbcfmTX0CUXynd1yB1KNW3RJyf6yuDVhe8goq4iL1crid5DTNtmSnCKuaI=]]]','2020-12-07 19:36:15'),(111,'[[[MeHfSlcqMsu4S57SyRRGUdbWhozrM1Fs+V3hXqH45EvLl18V/EOMQDSIXu1i5Q9+zO8UFLPgyymXs9aLlS08881oHmpwEhL11GbEscD1GlBw8sfKvTW6jVijK08ExUqRMKNx5bjD35MHpkba70QWVgxqZbPQzraplDGJHc0ECB4=]]]','2020-12-07 19:36:15'),(112,'[[[ktrYvB4sjG8ut/l/Kj91mscxIXls4FyNmoDvkE11E94AFYCMV//quKTmvu8gMcrtxmDKmVmHM3F/V0f41P+PhZPmlGBhqqDS6Bse4yDTFzJfE/gFnxMqF82IpIkbXQOL0d6i9R4R/j47CRSyXdkhmJIreX2vDZld/f5QL9IRvDM=]]][[[MRVYHMwTO6TA29+C3B6tblNv1egkngAoEGkcDUwkC8Co+F6SfS585KsPnasWbZTBK77trsarwyWLmV0bzp4PY6czmjrvt8rSwYXpjIQYrmvBFajhKBpkRAzI6q9018IwqLBcRUWBGH7ABlCJcpBY/uqo+sX8rR9BYcXVzKoFJBI=]]]','2020-12-07 19:36:15'),(113,'[[[LzYrsihQYEhnbO0E/pXgm9S5ViXePCzwCyZPA/XB1j21f4KM7VhhecsGyOntr/6PefuQ3JTi7bfQBvyM5A9KrYkIxourDCDkajJ2bhr7AYjqBeU3Ond+kHSDbE2ubhBGAqNe2Uxkk4gXj5HXUWhXctLSGvUboK7bM7u2lS+mRXA=]]][[[JT2wQMSvg8JekRfTryb4/JuwbRl2FnlMJKMSgaKmnfJi+ivLu+GMg3WsXq58Rju9IOxbnhHIRsBT8kVq/eWwwwl+uFDGkqeEX0KpyOT7ST2+Z/DBmYU1AIo/A1k9YXCyA6UrrcyZ5S45tHwW9l49RiVD76HHrumeQzvtjNWLOns=]]]','2020-12-07 19:36:16'),(114,'[[[kjYnDITeIPciXqcojuRxYL9IElszhi8AdQtX0SV8NzdHa2BG5/2gqZYSXsbeAi03FOCVp4bqFXpcVD2Ei1nNWOPK6v0GgT/jA22qRP7KjG7a0wD71/6lAy8nCxVrf4FWRLuYA9V0VmxMIiRjI9/PYohDiwmVQUV2jCEpPFTheNQ=]]][[[PobmRYwh1dFL0kgyomJ8qMxQr2a99bvWIOkiSTUPIaKp9BcByIy93cfz73pgSE0SzWuN3oNofT2U6HaLVjg0nBc9Ul25NOU043kVgO3RI0fLwwXYrHdlHL9Urr8nB7/+5+uBoH/GvtzrqwU1Ke3GqzvIb3ifxXbMCezVj6LpAVs=]]]','2020-12-07 19:36:16'),(115,'[[[qmBQODcLVHXtUo0EsQQMBiz/0CG34TZUDnQDJvURbStJGyU0LSjs9cpD3qPeDqH3IVP1bSLF+5e81LBZa+VV8DDvL856O2GEMn1wgEUlyYyATfl6s0AwBeHXvW6UiEVOeySam0dfRsUK4bqmEXlgTi3gFiUXVpILNbKSCiqyZKk=]]]','2020-12-07 19:38:21'),(116,'[[[AwVhuf6O6V185Kp7U21TlW0sVvLHKsTz7jF6/RxmTSLrVt0Sqhwk558315BOG4O/ofMsMzqkYrvKZmrvuUoOidWcD4azUXIBz+AcyJPggv/ov4X3KQAoli+FY0oO5DSgfDgGKlxP63uH807GreVcGnCMebkGHan6McN3q/YnfGI=]]]','2020-12-07 19:38:21'),(117,'[[[lZC6MjEIUa1C0m2GMlCzdhqF70AkpDsqZyTf0LarsqDHVA081/aEW9Tp7ftuujg5YHd9uEzugxTgIqqWx4gK3V5U7lMnGF5tcVrh2RgF+77Yaafcn7tK02IxAAhVTgCU5KealVZ5X8L7jQmPL0JFWR3M982VSxaErkc4h09/er4=]]]','2020-12-07 19:38:22'),(118,'[[[VgHitLec3DZnf5HTDcxpZQHnU8mspJysG3D7k7qda0nF0NeXHPY7h1F0Z/c8QGTSN37kGR2qcdIuRk49DhKyeMSgipVONuVGUX3Wnw5QyWqiqY69tMSxkFjohFRe/T94QNbLDyrdfEPVbJwZULP5KouiFFqcC6k/wgfLBnDl0I8=]]][[[Roo12n8XgTBierdiG65Z3uwocbmJyqe5BCahCifX/yhklRIw9qKjqtRJ+b9dvJIBqmEZKAqrZOwJkbAgZBef1j7dzknvR/DbJJNrUjyIHaU26rwYanqouJCetkY3z67s8kMMNmwk7nubgNRNjqSvlYxP1s8N6BZHBLsvaw3b2Z0=]]][[[kvqbXfRcxlcU8e1gW88EdpPXI2+QKrBlP1Tht18om6MnZvhTkufJf1ltjxYw459w0gHFGHul4/O1yE5bDFqHJm5lJorGdFejPoL1lsm4fMa5iR88Otkaf85St6HRaI5S9+txNbtuFyg1lT2MHY3P5/cmvLqgjhLqItJVLRB0OTk=]]][[[GUdJ+VFUf8MdwGm5luMjB8+WYLzpYNy63LFhlY63S0GEUwWfYsYVUxKT03oFRKS8p50SxIScGDaxrtopB5ustlbx/eVLL3sGgHbAxGy6MCZila18KIXq8QllTCN1RpjlyWmtBEthfWJ+LddnBbXtP+m0FI9i/DwoADM1nvnnICM=]]]','2020-12-07 19:45:21'),(119,'[[[Ma5fTZqxvUiUWNXAX1KFnMuc9bykc3kjqSUEYhYgQcpUIV0un/pPZwYx8zPx8OSKWwhVFmI9ouBx/+L4lz/DSrad2dS4YKg4ALkpwV+f4BRXrpdls3v0rVK5RaL8/QnKVWqgcTsk6SUknOxG80gxgj+ITIsUPYclOP6/KVIVCLk=]]]','2020-12-07 19:45:23'),(120,'[[[XYScKBo9daDr9v/9+KfFB4jnEj1QA88NPRM1Vs/ZlcOXIYC+gounLcyZT7/lP25+lkZa5wnsALtgEG+ZsYfOMQQ1jvVEgTVWB5KZcMcvY1Uk++RkXCZVS8wFr9JA5HRkaopBPPUPI2z37uky/CZP/A0A7a2+L5wutJwFJmRFGys=]]]','2020-12-07 19:45:24'),(121,'[[[PA197laj7G5RbpzBiqi662UyGg76SlL/ZZkL3kon8tVE/FIePcc5oGGbLQMhmraF51dSXjlfbiGGW89hr6b5XujtTCnGmDSfurgTR2P39We82PiHxuZN7nWhaMwBYQomFUI/lOIZ7k+ze16lxOvD1W8DHIsFog0EOdowblWfumg=]]]','2020-12-07 19:45:24'),(122,'[[[afYbJkmmEVprIHX5Vnu3zLX/z8rwA2J4ahO7PApn0LnUOZ4IFXGdiLi3qncJCruUFtl1jhWw1+juF43v1b4s5/A4B6h7XT9HtTzqaOhOWxj+4sD7TVN7cqW4RZreqiRTvHdFBdbPF0TxGMPZkX/q1FTXZmv9gHspkxRnrieieoM=]]]','2020-12-07 19:45:34'),(123,'[[[RKCIce5Nyb4fICpEDXJX9FMSZgXA5GArClkvVib9+Xnl8XetsNAfUBBfTme5DePDwJRT90/9ipGAzaar7c+z7IDbjZ1qq2Mp1CcWJ8uB5X57moaLpEY3HMNlholmxTYU/GiiabAG2hOEJU2rX3gV4ZoT+mGPAsnbMvGaQBAJUHc=]]]','2020-12-07 19:45:34'),(124,'[[[WQcqiCgGuZ7cSLszddr/jgEDz9XthyJW0dhGdDZK18FqZqeSQ4g0lwdjNbd2Smnb4fw+J3bzFwdP5OdRG++CKnqJR6DImeCGZhGKkj9ztxijNmeGEG4abeENFru4IrL1xn000p+QKoD8UhBd+fbuN3x0h8+ZlAgBZgh3dxx7i8k=]]]','2020-12-07 19:45:34'),(125,'[[[PN1VLqrGw5GNJJb9mf2M3p1yxE/b/g6Ho/SdOx12aq+UQjVxSGhOiaZv7uYb7oj3BA0dsUwq+re24oAmQTwdwCQONnOcxVXyJcKsC0erR6EGsqs2fu0DY42x+kpPy9nTiTeD7mO+FijiukCgVHBZKJ6SW3zFKlpWZc58EjZ8nNI=]]][[[VNKi4mOINdz973RcPe0EML9aVNXfL3gOF3pW/qfsJy3+8zQALhzQ+GtxxN+cegSEAVjBmNR2E87FRFCNrUOO+zp/j03SL3UwnO7NIeR90uytXyB8bVXFcOCEby97K0dZE7bOFWctBPGq64hJvMkCYa+iOalNHv00SR7AugJGHt8=]]][[[Z+X4GFQEYtJD7z20yT0lXkqAUHmI9U0BjOPol97KHUAcDtV9as3p+yyz83/mSAJ3oqewVHq/HeOUmj2RMnbNCe4r23BrlhJO6oso0mZjtdi/EkxWJ3DAIoLDDKxfbJUMA7tDh/30GxTsTc8gIG2gSD8kkSbHEinnR0vEC9JIdk4=]]][[[DLdEB/8RrlIr+lp6RM5K7XDKPmA69PjKRQYASF5cAbEbH2fzDats+o0VQfVq7Ho8dlcq+X/JxGwId3ljMgYjdyf1WpvNHKPSbyKI34dFyoyeb/7iyxfT1C20ee53uWN5K5/JE0M0KTSAQEbvsj7/wYBO5hjoFDoXI4euAWAvafQ=]]][[[dB6DUD05abmVaHeudF4wZefaHjdKmCWFWgieuiAXU6nxRvBftPw0UKtsreK+J0k4AR701Eno7rSzEbyJSQ0eICKVlNEGUSgZaGm8pzw6oShQ9U3OJQf9ulvs6pU93RgsnM3neK+dl4vB/mmnZyBPvWtVljQJj2MtkvuNh/1INnA=]]][[[ZrcLAs6ouBOcS7MFIP4yMvXdyW4K1s2k9mSgawsJTTXdfX9Zwuu6sXARSs7g/keErKom68cTEtea7MAfSpC/Lq4ppdtbSGgJ0PXzF+Vv/sbQ/0I6kwF+gRzvul3U0VPtFqRDITB6ViWUdpG18aGTpFjBNywG9/dCs5C27vzWkFA=]]]','2020-12-08 10:29:02'),(126,'[[[BN4JitJ8RVnUzazZ8wJvjNUQ/ulR3EMlZMm7U13e7HqsGPqTgPZQpGf8lBBQiTwOdvnC/yayQgrndAZ9pjz8gy/yujlJCyat61cdVhAkLeBh364p9YCUcljQCrQqvUbK1f1UJbD8fFvt34TivFCQ5cOpwebgiaiMpYa0pgeRLoU=]]]','2020-12-08 10:30:06'),(127,'[[[jATXrKemnZOqa09I1uTP0IxosLTRIiCyudyaWuzfX/zRbGGfYcPucmByXnNjkF1E/HlaibsTCjUIqlIJF9ttnoctyJlumjkgSzUSTvO1WyNqL1rWF4d9icyRpGoyq8wjGLOM+ElD6o7T90B5oByhpO0yRKEgrCK6jDcgW2d+/64=]]]','2020-12-08 10:30:06'),(128,'[[[J99Lg/NPI59d415xxkA0M50l2rURUR7HCXwpoFdsZA+v1YkN1ErMJ25hV+3nXqCdWdTbR4NYO4eTzyAW4aABx9XYpKqvrpIdzwbR+pU7EGpL0YujRLbrD/Xnjglgr4zMwme2RR0M88fVBOVYPA/NZRQpGCk78IZT1FiJshcTDi0=]]]','2020-12-08 10:30:07'),(129,'[[[O+XrnbriYprN+AC8jYODYatdJuq3w6slT3KpvuOhclFQgYtpkbHYQ9doOoSYM9pnxEqrzU8yu1KOM19RbAt6nSiLdp2xNYhMaVUKFqootvUBD/O8i2VjN09GqsWyCNkuvRYMaFMy/aH++T7VyheU8K+mejmNTv5752k9rFIgjIQ=]]][[[o9Amcm3ojATqhjvM88n281filtofS61cn49eluzirnGS2bnz9sGTs3MzPraQ2pqLh4PqgMQi/4DJaNvBr3zomQx8pEEt8d0uQ5bSJhrXn4lvdspknCLSQDR9M77Z9p0phQiUnN8XSxkTu1LYEYk/UViCwGFhnv41KZPOxGhj3AM=]]]','2020-12-08 10:30:43'),(130,'[[[fSt6xsBPRCgoiPQ0YZH+BtsBmzepSGJalqpSUCA4vvosw7G7JRq7rQzZI2Kk34hDlYxTAtuvGnHInCRmTCYENyrzYzyjIWtBeSQPkfY8sDh21IV6illuK1p2RTzwAJyFrHb/0MFr/BqQ41eS3+f6QdZxDXkeCTYlPQUEl8/rz7k=]]][[[irHbNGczd2oDV63tC0VWZJH+Y37WegNuTjKo2xokiEorLlmnVh/Sm20uT9m8YwgPNA5ML0ml1oCwt7UclTWY3oZtEUo6CzeAh+O0geVMqWp9Sge0pU+Uo3NK9nQoQOemLBNBUf6FNnCPWuQWcw+bM0MiM1quye32uNkVgiZ1Cjo=]]]','2020-12-08 10:30:44'),(131,'[[[h+T8+maH3RN6PY5cg6bz/DQIfPFVTV4iwMgkVVWpLjK1tFEDv15GK/9l9ENroEEf5D7Xouidc9HKHZ+HYW5/mcCpfXSZhBVt6K+NCYYUDs/2qUEsenkipcAbgkZFz1W0hB9u7R5Qvom6r7111KkXqFDaaG2eGomHHBPSxW7V0G0=]]][[[Ap5AYzuW1KZIpqL2hmsIgQ06tuQEp19hBU5cLRfblPHS/7nRCqjDQ721Ulud8eoQPGXf6S2qCZGPeoYXfAEFUdvm71wXI2DIBG85J9UdRvParSl+JK/VPBuTADYZVOnPh7Sko49zQE/GaucMG5b1lQYHIWZTlNdvSUZ9BbeVxwo=]]]','2020-12-08 10:30:44'),(132,'[[[iqGxXpmh63ejOWM5Cghm8g7cUIBvUbhH7jf8OORzip+zN47iZVu6pXtjxDbF2VSoqYakc+DvkzWdihYFyNoPZR9RP18nNybqUgSoAuQG9ZYzO/AJS1wN4LxNSa4XhXpZVkxhJThDXjkd1rEmKn2EsKWvw64r9y7PfNeHJNojI7U=]]][[[CKiLp2g4+ejo6sZJ2CmSqkvmYWiDY75YF++Rp6J7+UqbEyegtyRPPiyNdkQJYtvoJVeMYZXyBrg3GXn9ikzGfwmY2mg7zUaJiUTJscNQBu3YHvrCZJBDXDGZaiYmWK6u/oiwqIyDOp+71HZqE1K5ISLZoGFy6d32CD6kKK9oZbM=]]]','2020-12-08 10:31:34'),(133,'[[[Eae76otVOoCVcIrw5wo1+D9tR4xMk0sFwJ7CV7+ZncBXB0NFVTo5Cjne+5Rf4GM1oDAgu3mlMH8CvccXxwg019FbpUrl1dhXZNUWNKsLcm8RGubCFx3tHq78JxJyEE8MSjPg5/KDcCB41QyfrQ7KKhIW/TbDxrdrTM0mgQVaoOI=]]][[[hQxEjJntNA5yn/mS+rClF5XuUSRYwU2wSMcCDuJLVkpX5Ew6qRGXzqGtmhPcjF3wYyayh7KbjQ/C62f5pNlMgvzxKPl9VIhrEAesJrbQazm1JzztSXFUosq2uHIXePDdHGQGqveiCZXcpVTz9nRfPKQJppTHU7lD261nZluwC58=]]]','2020-12-08 10:31:34'),(134,'[[[bp2CUke+vQgISQ2FO5AgQB+3CmE+f6yLznZyoQKz/eZa1TUE2RkmmEfd5KCDV6I8p4jCfI91qhtC0Zr2GWYgCVh7AsSnzf6l7/Grg69aPVPNKVUO7xBU8ag59smFcCpdQOjJXQwCeZIIAMM3RR1bEUOwd7xdz4A+dOhSozGnWRU=]]][[[ra5eynQdtEzz34uJ8FFXX+5A3N3Ki1bVXQJ1SK6bXapOmQgXzPmtbPlXb6HGB3+CoVBRVjHSAqg7cm21QRkk3VXviUVSQP7EJNHHD8apXYsHbvcjejIilxBRtl4hRunxuYQmRVhhdj93OdkkZqVyzBNNpvKoALR+i+gQ7K4+K4k=]]]','2020-12-08 10:31:35'),(135,'[[[HgPixMkgNwrkOwFzS6CFXA7GAO/VNaFkJQIeZqpgpFehOK2/tlDRE6fuMxF9b2o4K0BAycfcnvGtr3y/JSsChDRcyJzPDd+bLT7DiMWfbArL2+xbkeuESZjt40UePy9wBbIIR/pEDYl8Z0/QqltlKwyUsP00T9eTbmG6Wsytto8=]]][[[YoEJHY7Te31205fYYI4ZM5ASdlvSEZw5Su1D+pty9l0TV7LmxtxIjMoogDW/7zoIcPAQi/+jl5PoVLWPaz7+HB6nPKy7UjqboQTWXPpa7T9ZgpACAL5Pr619OV5JfByriLSAQz9NwYW0HHIkC4pGQ1oiyoPqN6nWd/Peg0GotYE=]]][[[agZROjh6q3a+Jps5WAgHOC/sQ5EzAi377FOKxM4vj+J5Nx4cKlrXbuRGviUrU4IXDbhaaeIGf+t6xLG2YYSgo53JJPXqMaa3q9aktNDFhb3FY6UIAwLarnNxlw/VWHG7x/uh+IUhhbFyguGq/uzmmNIstcfdPQ2cfWT7KwGTvyM=]]][[[U1e9+pWQzD/3/HQXGkVeORzNXqMHxoqumBSFvMhfvwejEAIB8Yb1G7dbUVwkzCOGm5AwimwXYRrq37YXvb3TDtGtXygUei3lfSryNbJQWXbTqgpGTaMyhrMG8cAMxz0mNavjpfR8uty/r5xwt+JagiR0AI01AhMQZ1bH2zm/GjM=]]]','2020-12-08 10:33:17'),(136,'[[[FSdX2BMxlDkWBj+qSIbMKzDb8qENszty2vJaIf3dPKRIauyh+BZV93jzG06s+2K9vNlwRfxsiaQW+xDG1oEX3qZ6mav1ZIcoYlirHyFuN9Nd5ttOJJMI1uGIq5C07Mzd+PJ+xlM4PPxVn0NUHhZmX6ZaaN3X54Jw57/oktJkDWY=]]][[[R2SqFYarn6nRsBtnP1dLtmSQPKsHxYAMaeHry6X+QZV1aWkrx2A/SKbaqidpQjOqsurSRK+l6FvSY2agYj5VNIOryRByI9ft5IwgT/L71xYO0Kf0czzmbYpk9tvM97l4LRNbxaGUbcYwjopZ+pH1jZ/1xVeCNj3HmuhE1E5AbYQ=]]][[[KW4D71GX+sKdJATl32YDqIIDDGNWvMy9RRWtqdro7NrRa2F/+0LF4EoTyTWRCOAahgLPrB+lwYz9OQyJ3xxGzCQ6zcQXVyPIfoEP+HcFCwvHilCavF+jARY80i36sexZz7nPE95vZ6zHYuLlKSEApRob3fNe0GL66JB6sRH/hpk=]]][[[FV3QjNCzR//wzfy1i5iooXTm95ZinwibYIIpEowLBr7gJrV7qVJ58eo4XTDU9vfl3hg9KfBEUs5g7+MsTMnPkNQc62ZzLNf5MS+8XVYMZkz1roW86Z64n9yQIPU8p0gMX9zOjLPsC2s1yphNSRxPUQSk1losnLeoEF/au9LTCJo=]]][[[ECFbUDSezimIuAgV6kvufkpLtJq3G1U0mKV+r93wAa8cza5avPePFs4QthXaNLaqRWKvOeTl6ZOq9X6NwqNIU8zYI55R3utLPdLfbck2NkyUg+Ki3iQfYs15Z5Sl3wnPULHSvUSo8pqJrssesV/WEZIsjqQWYsRSrK8/v9tUVKE=]]][[[igZ40UGBlgxFTI3hxQ9iXuPzaf+a3ALt+T3kuPaAyepkP3WQi83DFiwAQ9t7ZVee6SFg5OPAHk7zCZK+d2ehmOcnwfgOXcOfsyIdCXK/R/77H880cA7YZ1u/5ePjydpbTIVyx3sT1JGssWt/oOoF+qWyhAg1OjgKbQhGOZ4fUtc=]]][[[g0R06Xj3R8upJNeHBnNrH7bYX+gy5HcO7DWq1vSrdUCCXLYcnd1FSKak02+aW6BtjoqI4AfNrzbm83pMhILDWT8x8HWvpCCZDO5I3K7jGeur81UQcWp7fic9GtJbdiHeVzDFE5Iji94SAqog4BOZjf82W7xCurNEbZ35lYA8zO4=]]]','2020-12-08 23:49:13'),(137,'[[[gPAzdbJCkH566HJeHl915/Q3LEaRJ4I1SdSCC1NkhJpiL7+8pfs3liaamR4Ics6eK5Qvh86p5WUD4+DtsW+jFQxY6j8UHxgs76BD122Lz1ADKgQslWHjmemmAXATiewJnhP2/KMLVf1Hl5i8e6i+AQO0rVFbhxIDkpZ9RMxj3cQ=]]]','2020-12-08 23:50:24'),(138,'[[[sA4jHfRUpKOdyQ0EIrBHoqJB1zELaUAI5miNPO2NK1qSpfZJd8S/CQqNbQuo3W9bdh4Jte9/urNicu598a8zXZTAKq4aDkuq6xIcOrkeN5AWPBrjFDQBW+zVY/552tdji/WXBtFaX3HJdT8cfX625eTxs0ClJsGI8uHeUOrC9JQ=]]]','2020-12-08 23:50:24'),(139,'[[[oNrInhHpRfVe5kZgpkcTlzY4LK6ARrHfAWIpauJtugoPOhA/AV16APB6INnxTD6qo4kekns0Buef1wm5KD5ojT8muUyIn+bQ3RprMuLptWX2jukJMAk6sDx8vMTRSLZFyJytdfq08fCNXAiAhlWjwCII6dhJ5tPvjLYiQ8uAmK4=]]]','2020-12-08 23:50:25'),(140,'[[[fHRBQIA6V3YgMlswCKDHInSW3P3Yjm98nWbqHMiDeURotdfsETM17u3/AcIYWKExgyofT7cKNk3EZCIMm61RBawyXQkJxOtLtlzR20WJsy3WFlsvMfarjV6rTOsi1SQFtKTb8Rslo5SDwKFul5GUvXuJ1ABmI5znfxrTibwHt4M=]]][[[lEH477DN7Ldddpaw8ZB5QTaxSpxGoRfI2Y887oL57X6+Deqysx62WvrWvsiXHGhuFWv1uY2NaNlKYydM9XaqyfZa5vBD8I1TnTmXfxYauauBEqRHGA7vd/OYGmXsc3FD8nBT1Dw0foUMDm0RQ0V8JFGMwYZWWepy7uztJq+uc74=]]][[[hKf4y3V+AS9SdNYpm3JQhGmWqmg2JuId9+P17pZVrZ1OwGz8B+X6k7gWJHZNKdyNWg8IlqgUH6IGwVbzmUOg1xRyp7USHjbJxECpd/VrviyriIYEdL3M1vw+wL0KXuHcXfCkMr8zVkK6GHprFixJfWizTPNzvv2/veBeKoceuFU=]]][[[gM+DMd88Pf6Lis2FXLO1MKKNw9xFcCnUsTEjjgjylQbTEbzxkryd65K1PFh2G48H5+ZGuW1SPJLGhCjuXxQW2JYIRGuZt4059VjIDUI+Mty9dLPAt3IR3DIm9llZDieOCaLg3ZUuEyerfA9cZqGUlf4ELGJ6MS7kwoau8Qooo3A=]]]','2020-12-08 23:51:04'),(141,'[[[feGPSYjw+otdFcY6yTJzl83GeKdb1VKel6sTFNA6EshJRbMCA0HvEulzLosTY4G39TbuyQU3RDLU5YgZlu51nhutziSGXNWHSmwAa7APR/cfs13zF9bLlUCkoJyh5dKrERaUCYBDaqCXg8kUXSinQWWaebNH0/8w+6VwFif/zWM=]]]','2020-12-08 23:51:06'),(142,'[[[XD3BYEf5cD7i4Q7a0lNz48fxIfKIC4H6gd97jv3BTeOYRzWuoX5sc4jiOQR3mL3LV7XeqsMNeqZfEt3XIkc8FHBmhyXlDiY45UO5Ep8qH60V+G1/DXAu8UZuLLt0Ws+lf7weYFUq2OAiadmQ2iAsuJA+0v1R3jzuLwDfVz2XaZU=]]]','2020-12-08 23:51:06'),(143,'[[[MLJHmJ2N3ncLZYeRSznAn+n7mhNlVld6aMlLvJMuXewWJXLEstPORb9KhFVKni76SlpccyEVfwVmILtbZIi5kDKKF1w+DAA05PwNwB/EBVHJHxn+347KVqJRb1+uuargL861AHHFYfSGgYFyGauOciMxDhfR6xndKCTC57tjvy4=]]]','2020-12-08 23:51:07'),(144,'[[[YP7McAQPEhClzNDMpoKOINRx2GFqHrgql7iWK5Uo25MhAIc1EqOM5mp0VcESkOGSGpGOy9+S1aAXDeczLEHFw20IWpXDWVenswdD/pQGpN/21PrP0DTwhZLXYvC0W1Qgmskte/tO9w/ApH8VyaW+zYsg+p/f/u/yMic4KX4dg9k=]]]','2020-12-08 23:51:19'),(145,'[[[tT3VU/R7BZYZVxP4S0o3kd3IRpUyjbPdQ2cV4T5RQeHMISMh7WTB0MBQRtpz07rZuBVLuMZ5mVZSznWb42pi/Ru4XjAw3hvDkx2NuP/QqZ+J5hQ+CsrheyTOWdZHDGBXjOu/3Twov8+aFvTYXySdsDO5dOrseaFD6IgV0Ib8yM0=]]]','2020-12-08 23:51:19'),(146,'[[[kNAeI0zIXb21hI2Pd4KuhvH5apwtzAN2lPPPPW/+IXTiVDt9GrG6S0p+uskuwBVS1qeVORdF51GYhfVzXuumoQYPY4nXOfEc5rnwDwAbPO4Wutbfvquntrh8Rx6awOGGg1hJF0NeaetUhtLdnRJ/ELoZO7FshUdh5IA8BkO0u/U=]]]','2020-12-08 23:51:19'),(147,'[[[tmsvEukx6cgN7Tr3mXPP1D5wWLw5bt4J4xplbPaXE6vJvywszB7aIfqbf/27jp/NbDP61JE5Es5SPgq0hLVO8+a6tV4AVwTGIo08GTwwyseHJO6OhltMK8NSWemqruFkr7/4DqKKvc49GpDg5nIhS9IH+5YIEjJaozvi0MX0CdI=]]]','2020-12-08 23:51:29'),(148,'[[[IBg+HQcD5jYKYF8DhMvEfYuxDf34/uwSjtMYeBx4FiN6dykqoUXiEd05aBvFYB02v3p/F6myQnBklKunoMJBIFpPi6ZXrN0p2FHZwCwD3tK33WR2zWcMvlHjr4sbRr6mks7ZVj3jlvZY8gxeM+Wr3PsrFYl9z9OiD+llc1LB66E=]]]','2020-12-08 23:51:29'),(149,'[[[SSN6myIGSfAYQIGOWaVPPsyWFD2KstE+CEGjMT6+8YwrcJoDltuvR/mITagOuZzG83nLwC+caIJvyaTsncmGJOK7gI8iIEF2mY3uNuOqjmh0vMraGMkUVoMAODTmwYT9NJFFYGz4ay0iQH8/wp9LHN8tKKSD0v6GoIIzoY0T7nQ=]]]','2020-12-08 23:51:29'),(150,'[[[naV15owW9qUwQXebPuy+yVMejxxWTPBjCkksjfnzm2OOrJyLMrrMQ99TMx1F7Xawax6tDGo5Ppn9Qb1nuxZmT2p3LCMhw3nijuaWV2Uzoca6ejHIQJ7F4lxXPF1+cXdD4fI6LEeT81GSxl05eybclO5crgHC7awUcDt8UlKiUe4=]]]','2020-12-08 23:54:00'),(151,'[[[qTklk4kCAVMoiHSQfPSb+mqOjHFvCsfEEaiSPXPDapdeQKufyazq8zemNxF+JBuPS0wQXRcKvJNpCKtgVZic4k2JvoRGLSo6Nidc+xLLXrgi/ZZrfEeX4QKZahL981/MXh7Ao+SZ8NaVIkhyLjYQZDXPz1Kcg6xIpWSXRKLtqqM=]]]','2020-12-08 23:54:00'),(152,'[[[FA/xQh0b6uRNiA9Hc1NKr0UeRPFed8mr4IuEQvOYSOysbRcVyYjRCluHkhfp2XlObIb2aJsZyEHvDcnQinTjxBGyPb/rUzJQQyJFTiA+3XJeUH9rd/fxyb5MkYPMvNVII6kU4UdLZ5NbJ1/TeMMZMMS/40n1PJRmvdgVoirjGXE=]]]','2020-12-08 23:54:01'),(153,'[[[Bd5YRpsrU2X3ElskkScAcBXRzC4M5pgDjhIozoCjE5gw/ADIkfH1lteRgDhqKTkShQG3OMiHiDepF27YVbCU0GQ+H3wv0oFNOk2gVzH1fZz/sRKOkZ9raqcs9jjfvngPBqRN9RoXl0jo+ycB5pbyNgbVpzpGmJAuqIbOi4x4vQE=]]]','2020-12-08 23:54:08'),(154,'[[[BJDFMyjB167SRbyuInHcH3S66LDoZC8x5ltPtj80Pwh2T7MUtk/3T/NR4+L0ufjeocPA+EnUlBPpG/KsPEZadrVupFJs/mteGcdzQBGVT1Rq6cuwT62lhbpkoFpifVDoxXPl89DuU90aomCejzWD9uG94C0XAuqwlRUnGz6CT9w=]]]','2020-12-08 23:54:09'),(155,'[[[KCZ5oL4zCotIXEMCEgfq4h+M29dxM0coTxIJkPeroiAduLiIRFbPLqCfGEpvO1zWCQS+sk/WKvPMwlMq78ABPVXDg8241xRhjCuD7ipX+nMIAFhdMX738pwSBW/bWdCjFm2ECt8VvjT/++AJ0NSL64XIHc8cnApzJx0XFTlDLqU=]]]','2020-12-08 23:54:09'),(156,'[[[I2de1fVF9CnU3W3tALLMDmeoIUyhyQIBq37tzGPpSoKW38CykYfjxL1LZFffuL03R5Z+0YxLe2WZzW3W4Hmx/47IhT67tPMLna3cdiLepbtxaMBG4I6+XPq0hpZ/C3glPCeef3wSWcoKb/dc6QYG5vUkfjKCwZ6phqXhE9jD2Iw=]]]','2020-12-08 23:54:51'),(157,'[[[l+DUafMz3EdFifxJiFpi+shNMekW3jMY7cuZnB1YKs5Inkb0C0vqN3QDtU9uAZ8uBOYrGGzzxPRUlzpjB5blgkTvUFszKLm4jsP0DBFPh/gNxOgaGpmNRhe2WwNVWOVbpDjU7Xlsj0Px2KdC62hhsbmvkw0OdGw74XYWc3gI3nw=]]]','2020-12-08 23:54:51'),(158,'[[[sX5WuQ9RDWMjYkjt+TK/bKfeTctounWeB9vM/6vM7jfiUrR9+homnY728ozsMfA8y9Qgi/Wz7YVeNZUyeFsi31WqC7XfdJpUWSn+gV6EVubpA/QTqSGPneSW6HJtK/Epi7RsjJC7gp7IkCBT3x2jGlwpaPhDOq6lQiGSKLEu2CY=]]]','2020-12-08 23:54:51'),(159,'[[[lRNYIW8Fb+vm36iOIjjOVM+nWox8EbvN0Juw97UWiN5y/iKG2Kj46TbeJCYyO7FUj5VhNzXHIM8VFjyjTrzAlQ9xsXq0fe/ErMpXlumBYoPY4s+jLIjaSO/MMk4R8VzjznyVbFpmk5oMPUMBcY32Ct0FbkMVeCQeVwoinMSlWFs=]]]','2020-12-08 23:55:03'),(160,'[[[Ji5V5Qm6KF5kZfjCvHnGjJ2Asjt5SFyeZ6+/H6sB6+duwK3s+yVG13biEpcpsHYYIWWJ3g/Z1OQYUOnVOK9TRXJFxYfcLgZTCI7ZpwhS/U8lKvOB1oqTCXPYmuE0q7KNaDbxDA/F+twQpf0YXRdGCsOUxttkyZjEzpcW66jI7l4=]]]','2020-12-08 23:55:04'),(161,'[[[rxOjTL6GrvCLxsx3DDHSr/ug6J+oZk+QfcriBVzD5DriNPOW9iJ9gbMUaIZFwjaqi29B7tJQO1wtsFvWWQAexvLnulr2UoewgChyeRxG/lVhfTYqlAYHfLmhSx40DQaW9Z6Ofe1vDPiGt2KxrjHRwt3yLdCrgp3zOLr72nrEr+Y=]]]','2020-12-08 23:55:04'),(162,'[[[ovrJLAxpOjz7lKmmyoRgVVkHLquQeSmUilUtDGL++lGxLYhgTVbJGiu+R/d6huaW8ihJwXrwXstI4JM6Yesfgc958vaeK0XlKc3/ls+o09jHWzBEiMlPJSAOUlIDDaF0coTf3vBScfvi3tO657uYvjfF9oqQ4g8VcOcASQ8Wpbo=]]]','2020-12-08 23:55:19'),(163,'[[[qKOBYqydkICCOXXQWEQrL4hVkW7KW4pGO+ulqiueG98zMGTw6AxxbJXCkwKaWQGLNmaRuUcAeQu8b2bIPdv+TGcNGjjmRt7EPvWwsbbeeQoLrfPvPLhOWEa+HrwmgPAE7mQ1ECur54vP/xPd7poMJ2nTTYdm+PFxLVf/uGCHbXw=]]]','2020-12-08 23:55:19'),(164,'[[[JyXT0ClDxI4/J/QQmO3DxAYylavrgoZvR0fkdMh7s5CWupeZ4vB/sLMGrnacaa2+9QwFdsYSOv6kJKLm5wd2JaG6BBwEdypEyOPT2R/vk34lZQdNxTdyU/HGeDg5RoXUURoRS6qUFZgoCZSFf122u9vqiW0T3+6xxrj6YG9ISds=]]]','2020-12-08 23:55:20'),(165,'[[[kydMcP8JWYmG2RG6QDgreJ9AxAC1zhveCw72H2z4u9y1JGAa09ArDCnu660I4MAyVX5yFJpsUX1omUeegLGOhEqY7TVSoDIKSkoF7xqpv9etA9Z05XGX4AcFZRsZIRE8qOn2gVhAJBdB1gu1kb9wN6qM5XJ/+FxHq6JAr2cwrfw=]]]','2020-12-08 23:55:30'),(166,'[[[iZey9swYJMUiprJBCqcERQStRMFw1WZ1D5Gdy9TAFbClSiI0V0FHSGnkJ9AhBB0SaO+y7gbtvhqGKHkL86GtPDCAYa4Q3Ztxi0y+h/Y5CcvAYh/YraSSytFAv8VTc/7nnSQ5ouqtklb5wQZ+Tlq5j4h8EiOnmxKo/KEJjZJNyfY=]]]','2020-12-08 23:55:31'),(167,'[[[VheAiNCkoKdrfzJppw51zIQTR1dMjtVei9Y25znuHwhtSPdaVYJf+vPbYVr4p+vfymvL+JNSwMEKPCJwgqDkvT8ayGy7kIa9aayKnDGO2T7jdH1Hm5kYAp9pLRtZ+bY98BPwbS67J/581jGSkRTzC2ePwSuf6TjQEgB6eI8xzpo=]]]','2020-12-08 23:55:31'),(168,'[[[YWoQKlXwM7rfWs4YeZIGin878SGdPN1yU3jJZXcahcKXDYyl6yqqdc0jJWHFFsSWbBzH0lid84zldGB4bD6nI8xL6ob6Th/nAkin9NkbdvY4OkwO6umcTe5BLcsoA7jdhxnsooFfjmD43YjmGX4A6DXENDzXYg80+JxLygD2biQ=]]][[[IyBKacr5bwdu4hdWAYtWtSx8G37GNnLTHCIXwXPqNtfxZRYEZOr+1s9RIR9unPQQyPuuSWnW1zJyuzQNR8fOer8FvBJmVDCUMdmN/xlJUDviLC14DFSsTSG1cU6spJtksYUqetyPcEKZzJhCxMufZkp/OAERbXc0TM/jbNazbRE=]]]','2020-12-08 23:56:13'),(169,'[[[gSlST1GRCQK+zDBkpr1hwaGPQihDTSvKAykz3I6AOXDYuKVBZrIwPpBW3dzB3+XlJl+h7lpw4N6Genn2EDEkxZrfguyxCTh7wH02FMeAGPNDx0dsdvE0eYfNFzzmwJCrZIrpzBBfLy5qt2mGZT4v756uvy3y0sCupsNZDh280/c=]]][[[S9vsEYXf3nRDvpoHQZ+QbnW3RedD2VRDwCaOOFwA2K/RJRcA6ikWxrGDf70VObAw03hGu+Cn+vlLLAc4mufpCUlhTBM40huF6bnhCyxSjawmVBcj2SFh5jWJyTMA2qpIgq17QSc1HBa1ZIdN+Sob8BKYFBl+yHeLUUdzglhuTyA=]]]','2020-12-08 23:56:13'),(170,'[[[DTelOD8+vYDUPkzgtKFiWFRN1cs3v+0XtLTobYnNok5Oeerbh2hCX08nrpzRCZ2/tdNX5iSV3lturOGvkAWYInqWyzmZJh1OcB1hUrxA/qxeEeyQUAiKXFMTF51advHEvGBYMBHFRSKvc5n5Wh1eXXklVIfZr2mHfIAWyf2tyD4=]]][[[X1WSKHDLyz2bidI829NCtjndx2l5MKARnzrbKpxnPG8yPPoxWDOwtE98EWKoOdpUQV5P+TuzAneIBiaxe+q0xC4iSrXFnsFaDMiXPpZp9dJNzJu8vDy4Up9zJCxvtfMkFXUpWwt3TIZPb5r2gw1gDRAmbGm/bZxPmQllV+nxElM=]]]','2020-12-08 23:56:14'),(171,'[[[Ktua+YiAPbrF0PFxuMW+Ted87izVV0VpWRl3dyh15gdG/2Ps/D5feRq4qKNLeWBba5eOFMwOJpxF6948gXbMuLJJnpkwmyd56CH0bQGXEfncs91qzvM85GHtZQjHTNTxJfPa3LsDDBnKRzPPFsWE2grCSKI+EQG8VbehSVmz2IE=]]]','2020-12-08 23:56:30'),(172,'[[[c0XSXRcaCG8hTlgBDUvmNxHpDCg9NvlPHObbQuKr47N3djoTjiN7CvJ7LUFC+Yo/N6wT1Ke97oGqboB+bGXM2jU/mE9JeWkTORw3aJP+9rlMCWCW3uvdZLxONBZQSM5oUivkKkT1r5fEf8hbSUxgHee5KzX6/xqjDibMwvtzgFo=]]]','2020-12-08 23:56:30'),(173,'[[[I1D3aM/diw65ZH0YJMdMXhxq6EX/UvI6DqxJzMzm8qKshXaTE4nNR1PzVK8r7q81rmmXL/3vKgk3vNlC2m9RQr16vjqS2kocxtMHw1NP2hzxCwik1m3zLVuRjZ73mLr27fZy/Uz3iKdxKzcFPQDKv+feyZRl0TFMtSfH+bvhcb8=]]]','2020-12-08 23:56:31'),(174,'[[[WP2hsqqeZv4Zi0/Ky5pfDH7O7IZzk3CjhKUrgD9P/GVLFLXVedwQiqNBxEpGAG+mbT43vG5VZ1h4cvKnA65qTx1GOZEyt05SssTfWqyNIPFkNA4Nj4XIAMAjsqkwwfUHi4PnWkHNadEdyXGknC9Jf+9xhOZfnyzogm3p2vzWjrM=]]]','2020-12-08 23:57:02'),(175,'[[[Z0xk2FRgnZOo/yBVOQdIbooYmmCg0+EUXZ/29ES4mEP5jNgewbQSD5nfQn1wyqUQpZdcoMX98hnI4N6SJ3q3c7Qzz1O0DV9Mxmbfl5ueZkQKUzWbOSYVRWhBHUf/PQcVXj8wQDLm9yp2Cms21k56wSO0JFV61jo0zdJ2UH4BGss=]]]','2020-12-08 23:57:03'),(176,'[[[hg08ab9hfeNVtbjTerMpalu2JA/ru1w0+pn0hF6gyWtceaHApez04XeuQJeOr1zMOCE4T59pw0g7zdLYmLzUf5GUk+jAL7XQMGkXjHq2gEjdIFUETroEiQzMXCxBxT0iY+0+H4AgcAHKjU/9ewKw9owsJ12HbOP5YU6F1m18Y6s=]]]','2020-12-08 23:57:03'),(177,'[[[K6DXCcFXqVeGNGwN1G0Z5cC402qDMquzpxn0kITuklbK2BpELqv1dRz61hnoRxi2tkJeYRaDEJ09WEJ/QYOxzTTwKWB4uN8m4qhO1d2iGof9ZDIqrfcIVTHiqE22yQ114ZlREUIFZWS91uj/Sq50pxTJVfOYRRkkHAHAGAZjIwU=]]]','2020-12-08 23:57:08'),(178,'[[[nHVQTJsKeT2nsujqMdQBnnnBt2slz7INOfDLak4QeDqHMPDBig9E9d65oYNIVWDbibKl5lxa1n+hejLFzNNfl4Qx+/5j14+IWTrtgjvhtcjZ8r8+EdQSyjzuQ87mJvi8Ol8t2wlTh/oqFugM/OyUtJuLRaUeUyNijVJEjnc8S7o=]]]','2020-12-08 23:57:08'),(179,'[[[ZJhtmx8Zf2nTTgSSStWX7ODI0RFksiIX4Hs4lY345XtcgVTU26/utEEizC6+8FFqctriD78+/NR0fUTl/5nzujuNugprRisRCRo1N+dA47d2VLHSu93oC+49GwXnNgV/2cfgtQdw9Zkr2SYP+NEduQGh6tCuZFvOVnaPx8zp7as=]]]','2020-12-08 23:57:09'),(180,'[[[JI14rgWOiGaTrqpTdfdeXIJWwR0L5znAlYsVzteUkc/JGI78WLS8KajvM40EL2vAG8yCoKkHc7BKaycP4zqPqM7CifdF0lpknY0GkejnLq4sIiS+3aZs1K9Z86ac/fFI6B7aPX+AXZGoYchAMDgBM4uvieF+9VhQX73zbKhWf4A=]]]','2020-12-08 23:57:15'),(181,'[[[ZfAdZIYgTGqVP3GlruT8Fb0JcEn/p2f1cQKlvZjqNTF0oIb3wu/Pi3T9D4zcizcXxhk4Z3lMtqHK2fkQEkthJpFV0Z3xPOJlaWKKhv8ZY4tEh5HZSWL2HzCI1TWjAPIrhTb7rdC9gnXPv2ez8pyLznby+IHTsAK16sJpCcZ6g+A=]]]','2020-12-08 23:57:15'),(182,'[[[rjBDxHb+tVqk3ZHWhPuywNEanwnvEclIYGdDLbunqL+d5zdv7h5D+E66vheOsyPmtlrb4QymgYFGrzCM7nQi5T7bR75sYTl9NY+lGBS5r75R2zG+6WJfc/Omg/ELSevvihfH3Rn7kcniRq8SwAcuHsdBY5UDzUSClXPcsKSC9rI=]]]','2020-12-08 23:57:16'),(183,'[[[PhBI02nuOB9lomhWPEmSriGD6IajnZlDZoDf/JxsNVaiwYdNkoIEkTJYoGPx4nnW152wyy3DCeg5D/2Ge3MYY+W5ZFJJLq82dCeXr7vlh7tTagDXHqDG3hh+yVRanixD/xNrTxTFabMKfvHBw03pE2FI/o7kzIMrizi90TMVOos=]]]','2020-12-08 23:57:22'),(184,'[[[BL5y6eMib7SnlTGW0BEfpJ+7bC/qcypUhIlCRCc462BCT5Vr2mkRS7sj7bDsO+XBrB7iBd0uwf28DI2NmYdWP629II6afRZLq7m+47ouozO80RKRnlZ3lR84nOTmkMVSMZpZTnOUG5RlOc1CFXPJ3d0wiN9XI9CWtvfitEiXU7Y=]]]','2020-12-08 23:57:22'),(185,'[[[sVRRBVKtoQgYOPQrgY/tHc89JU3rDIxlvSxur2dWbrfFwJdfBS4Zs6vt+BCrsIiPNzmtlFUagSflNWGNM0681l2dXZ5E/78yj/EUDabT3HtLu2cGfeuE09jTAe3oqbT89DLzu7nzfKh3iwUQyHTLAwM9SeSOVPO1DTedv6U16y0=]]]','2020-12-08 23:57:22'),(186,'[[[rmODkZDhfP0zkH1zBsewQ3dZlQRbmTL+H4B3dHLE+gntV6MWbC/V+20MtX83zKSvVCcMJ6RLtCqBC6DFKzfZ5uOBmm56WXPIhUQcSj7GfzNM1/LysFa+yeTnR1/1tQkqJg4z7cr1r3Mk6eK9QS27UbAKlItizUaQ9DJ+YefEGfs=]]]','2020-12-08 23:57:38'),(187,'[[[kRearZxwq+n5ynjLxT7iRAN4kqMHsy1b5EgnVNhzW+P6sIhLnGPxIkmkik/W3+H73aq++SS14f1Pt9fnjOxmWgTWuUH+mCzrRoBfvdz5N+9Ns9xxLl548GAQUSykFpOH7aXL2mWY89S+Kga9yUn/9f0WNJK65vxA+FtGM9ff99g=]]]','2020-12-08 23:57:38'),(188,'[[[e800JvTr9moJHcH6btgCD3U0TQqzphcj09vXVPT4vYRD+5zn5a7Tpo3QXZnpzXUiIymO3cZwUHTszxJYBFWnUwwzu3hebVqxfoqX2rK+/Snhez14IgRMRiihqmikBmOwio+82QuaagFYCKfwC5N35/LlHUncHV8OfzxJEGvZ7/I=]]]','2020-12-08 23:57:38'),(189,'[[[JtqbLG+yl9gSk0La6Q9pvToGy6Hfhql7dRtT2DNc1LXINYc9PI+BvbzV7RZLo22y82Zru06D1M404EX1P4TAW4QSqLM91WlPbJYFRT/aWCnu87Xu/loldAmVnVQr2EaBmcLNzqJPHxhpljZ/anjGvOzOYCXJ8Br8Abyu2TL7+CQ=]]]','2020-12-08 23:58:18'),(190,'[[[LHBjLz99zZAGyY8L7H2AdE4aRnzY+X9tHimYBiO5mQeG/QwbfTvHjAcLkUp1L4OnnD4XhzapTKLB4jiyOjToFgNHepF/ETXg/eoBPsLU6pXC6YF68BasN+x30ZI+TY8muJvPUblU3PucDTD20ZDtjpT50lBEm8+d2lJe0p1ghgU=]]]','2020-12-08 23:58:18'),(191,'[[[kOsjRW0klM/Z2agBArY8IBD2kVpx46rL2W5HebwL/9hPMQhoTkLgqf+b/c6c7TzmIvTtL1j6eMWLLai+CMZlmKMy8mIMch2r1g4c+DafoGNwyz3PunsdfBcuTnU/y0xEfDT+S63lkpl/ILNlBdl/cjveNLFonUwHHjbJwrB9SiE=]]]','2020-12-08 23:58:18'),(192,'[[[l6ngZDH9WVJUh0zDwzSVBOdR+Dh/hQWyOeFKBQaRFSZZzLKgYnlHHPg+679uJmQCH1jrMZT5AX7cg//pqNlrE8ID9HvMuitUfijF+Dl2jyGvWL0b0FjiIOQwfH7Lo2EkugW9MqqhqireTXu3bbJPWhw4rbm6NySodmC9Vmvoybc=]]]','2020-12-08 23:58:29'),(193,'[[[DZCgSR/zmyNJZxNhOs5nC0SW2phx4f7pzNJIFNZ3J0F8KR5f0QKzFr9MwsbiaF0sRohmsJSpM9vGuuUCcLi5VqRJyW7m/A1kJ0E8SEJTqIrMXHpw1yfePFm4WKTr1BxGiWuvPqCIK0rAyvbH+u/Je7u7ebHna4voijWdPb2g2uk=]]]','2020-12-08 23:58:29'),(194,'[[[bBd5thlLQG/1Hk68N16bbiHfPOqZBne7CvNLUY9nJt01uCPKMmgYykushlJ6XwK3rNsoIbcjUFxdX6sRxF2U0Ew5k4XO+GT2MOI9dcJkNuOl5O2ve6njcIDQkmdtIXIFE8i96eu+hBOkYQwca55vxhxcDEYP8RrdwzFScWy3dpk=]]]','2020-12-08 23:58:30'),(195,'[[[S9ftGw7ObcPmzxDPKo22zncPRLw0pt67z/jlk6R5WLwImCAR31CLYo5MgHWknLwTkege7H+knzzpFDtYPt2QssVY7o6FL8EyDna9KO5ijY2KXs+izW9paIq/TRrL6uoV+cEF4XhV9SvAj+1wYzviN84ePC5mEorWY3O0hr4FHZQ=]]]','2020-12-08 23:58:31'),(196,'[[[ojEo/NKT8ikj0gfJBNz5y/Tvwjc7q/GCh4/pI1OPAx3xulREWgoB0jhiNU+W3z4N2Ay9OomNhvi8vPudeFHGyg1yQFTj+w4wOMcFUhoWFdgte4ctXPQl5zQZL8bYdA66n69lIwt17OSo4OlcHp1ijxkKybFr/JlJVdeaEM/HXjQ=]]]','2020-12-08 23:58:32'),(197,'[[[hhYPUPFU5h7zvnZ+K87doEXzHcMj+BdlfbdRGHoELRiRpe8TbHmf1bDZlA0AEAoelw/Z76q/2cn8f6okRKpwrK2iiFI1qtTTMub/1ATO8Ur/Z/9OMsBnDCsiAspZqZLZHOzn+1gw+4edCOJB+JcgZE46INhX1CnHadbsTLyPhew=]]]','2020-12-08 23:58:32'),(198,'[[[FTp7Smox8xPlH/XLlrjfm+NDn9w3IsZTLnGWip8qoX94CmxPy2BC78eqcXaM5NjVTsu8xs8xlnVAti7so/3enSgzUu9Q0rphxW6WEDr2KvtJH792p+WAlbzD06ia9xWS/WPh9xAvxYYpcu5yO5ed/gEMMkQI4ptTznqVfgF0qSQ=]]][[[aeO6mKLfEuP/j4hhpE95Ihjlgl0N1syzKg84Vu0MRlswhIXYcmjWq5l+HXFU2Qf97VerJ1/isRGdJqk4KCIUo/Lvpqum/FaWvsP3d6wyc02OBiSmSmgQrcV17/KHHZ6NkKRadtUXMN0O5NdRjkubvhD5S95Io4OvPlNSiYhFj2A=]]]','2020-12-08 23:58:32'),(199,'[[[cc7DDcuP+2iUdcm+2i+HQY7zSEmgRyEAc4YdNXGzW5cj/sDGQVmWOt629mjxSxm6JbY0gxUktkPoyq/9a927zgz7sTEiz2g+z7Ug6DfxFdGN1f3nXe2IDz0AIO6wW1OXkuQP9mQAGnOliFZIoLoDOUVP8MQOzhoVbA+kCx3/6R0=]]][[[Loa44wptCQLgRMAIdTN6iQJFOgDUX6LP5XMpU86g+2qUqOVN4tZvop2VYMqGxq0UFDT3OHDmR4vQh96BAzUE4AhwuNPQdOWaZ1cKYnOo/nRyYmU+QnPEZCKF/UHo8y7ClvD4wFr+2b8Vwdl/M/H5B7dgfn2f6AB6C4k1irZudX4=]]]','2020-12-08 23:58:33'),(200,'[[[H6nPb8otWPbE7rY2qkDyllQLVgdAIpT6J41aCKqIPXYjVQtEwfx5rnoGoqZJxVq3fQCKJ4v/uMgcRRHoATk9HblYPF85mj2Oh6s5NfEWE/boSddtpblnwAWC2SufQeyr6+IXuh8j/7OooAWFTP1b9lLKfGfH1hUpCj6vatwxFO0=]]][[[DN12dvVmnUthymszFHZMw/nQRXLgU1sMj8E9rL+HNDO8cm+C/GAiBSrES0n5a2WYaQpx0updbkZI3xGfYF34M2LX9ystS6CEhd0GTwrVgJW8mP6oYS026I+Jk3pvVwr0Wo+N0utfgh/uwc0bf+5x6n//KSaUTjgOIXF3Dqe+F74=]]]','2020-12-08 23:58:33'),(201,'[[[pPGlJTFIjS66MEjTkm4bVSGTNp1Fw6hr9D00dJY5P6hFWf6zfR39CJerfRmBl58S4KPPa3Ef0XkgaCLvBZXbsu8bUO9Qd8XnUxWlj14FJwfJmOc05xZHFWHfZN0hiN7jL6yJI4QGAz/FvPBUKMolWcRGiQmDC79FdeFUl3qMHEQ=]]]','2020-12-09 00:02:42'),(202,'[[[BKXrTmRnvSjAVEXv2lYP6gblpjmgGBU4YrlPgoAQj9Q+H4hvMTpKRX4D5y7+ITMMkcRrVlLmkuPedgkElFCxELf9iA+ahV3tA92UfbWGvVu1Z27v2CHlC1eT9SBLqlvSYP68hU39n5YnV/nB6p1GwDj/IVtKq86bvRHO1cTAvXA=]]]','2020-12-09 00:02:43'),(203,'[[[byYhFHKxr62WSZqZ1I0Fva4mw+fkhJJZUWkRlpOPDNGUObYXn9Y3gTLDsL1xf3pimux7LE4STzYj+joJXU5rUW2f+rtbwFrNpmiaermqySykNtlTJXqtfj/N8sI5GXSubBNJeRTV5Gxem6Yo0QHCw4/+OaltujLzBXJMXeoOOKo=]]]','2020-12-09 00:02:43');
/*!40000 ALTER TABLE `hm2_savelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_settings`
--

DROP TABLE IF EXISTS `hm2_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_settings` (
  `name` varchar(200) NOT NULL DEFAULT '',
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_settings`
--

LOCK TABLES `hm2_settings` WRITE;
/*!40000 ALTER TABLE `hm2_settings` DISABLE KEYS */;
INSERT INTO `hm2_settings` (`name`, `value`) VALUES ('update_id_user_notices','1'),('update_id','100');
/*!40000 ALTER TABLE `hm2_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_tell_friend`
--

DROP TABLE IF EXISTS `hm2_tell_friend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_tell_friend` (
  `user_id` bigint(20) NOT NULL DEFAULT 0,
  `d` datetime NOT NULL,
  `email` varchar(250) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_tell_friend`
--

LOCK TABLES `hm2_tell_friend` WRITE;
/*!40000 ALTER TABLE `hm2_tell_friend` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_tell_friend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_types`
--

DROP TABLE IF EXISTS `hm2_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `q_days` bigint(20) DEFAULT NULL,
  `min_deposit` float(15,6) DEFAULT NULL,
  `max_deposit` float(15,6) DEFAULT NULL,
  `period` varchar(10) DEFAULT NULL,
  `status` enum('on','off','suspended') DEFAULT NULL,
  `return_profit` enum('0','1') DEFAULT NULL,
  `return_profit_percent` float(10,2) DEFAULT NULL,
  `percent` float(10,2) DEFAULT NULL,
  `pay_to_egold_directly` int(11) NOT NULL DEFAULT 0,
  `use_compound` int(11) NOT NULL,
  `work_week` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `withdraw_principal` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `withdraw_principal_percent` double(10,2) NOT NULL DEFAULT 0.00,
  `withdraw_principal_duration` int(10) unsigned NOT NULL DEFAULT 0,
  `compound_min_deposit` double(15,6) DEFAULT 0.000000,
  `compound_max_deposit` double(15,6) DEFAULT 0.000000,
  `compound_percents_type` tinyint(1) unsigned DEFAULT 0,
  `compound_min_percent` double(10,2) DEFAULT 0.00,
  `compound_max_percent` double(10,2) DEFAULT 100.00,
  `compound_percents` text DEFAULT NULL,
  `closed` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `withdraw_principal_duration_max` int(10) unsigned NOT NULL DEFAULT 0,
  `dsc` text DEFAULT NULL,
  `hold` int(11) NOT NULL,
  `delay` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `deposits_limit_num` int(11) DEFAULT 0,
  `rpcp` float(15,2) NOT NULL DEFAULT 0.00,
  `ouma` float(15,2) NOT NULL DEFAULT 0.00,
  `pax_utype` int(11) NOT NULL DEFAULT 0,
  `dawifi` int(11) NOT NULL DEFAULT 0,
  `pae` bigint(20) NOT NULL DEFAULT 0,
  `amount_mult` decimal(20,10) NOT NULL DEFAULT 1.0000000000,
  `data` text DEFAULT NULL,
  `rc` decimal(6,2) DEFAULT NULL,
  `allow_internal_deps` int(11) NOT NULL DEFAULT 1,
  `allow_external_deps` int(11) NOT NULL DEFAULT 1,
  `s` int(11) NOT NULL DEFAULT 0,
  `move_to_plan` int(10) unsigned NOT NULL DEFAULT 0,
  `move_to_plan_perc` decimal(10,4) NOT NULL DEFAULT 100.0000,
  `compound_return` tinyint(1) NOT NULL DEFAULT 0,
  `power_unit` varchar(10) NOT NULL DEFAULT '',
  `power_rate` decimal(20,8) NOT NULL DEFAULT 1.00000000,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_types`
--

LOCK TABLES `hm2_types` WRITE;
/*!40000 ALTER TABLE `hm2_types` DISABLE KEYS */;
INSERT INTO `hm2_types` (`id`, `name`, `description`, `q_days`, `min_deposit`, `max_deposit`, `period`, `status`, `return_profit`, `return_profit_percent`, `percent`, `pay_to_egold_directly`, `use_compound`, `work_week`, `parent`, `withdraw_principal`, `withdraw_principal_percent`, `withdraw_principal_duration`, `compound_min_deposit`, `compound_max_deposit`, `compound_percents_type`, `compound_min_percent`, `compound_max_percent`, `compound_percents`, `closed`, `withdraw_principal_duration_max`, `dsc`, `hold`, `delay`, `ordering`, `deposits_limit_num`, `rpcp`, `ouma`, `pax_utype`, `dawifi`, `pae`, `amount_mult`, `data`, `rc`, `allow_internal_deps`, `allow_external_deps`, `s`, `move_to_plan`, `move_to_plan_perc`, `compound_return`, `power_unit`, `power_rate`) VALUES (1,'1 year 2.4% daily',NULL,365,NULL,NULL,'d','on','0',0.00,NULL,0,0,0,0,0,0.00,0,0.000000,0.000000,0,0.00,100.00,'',0,0,'',0,0,1,0,0.00,0.00,0,0,0,1.0000000000,NULL,NULL,1,1,0,0,100.0000,0,'',1.00000000),(2,'100 days 3.4% daily',NULL,365,NULL,NULL,'d','on','0',0.00,NULL,0,0,0,0,0,0.00,0,0.000000,0.000000,0,0.00,100.00,'',0,0,'',0,0,0,0,0.00,0.00,0,0,0,1.0000000000,NULL,NULL,1,1,0,0,100.0000,0,'',1.00000000),(3,'30 days deposit. 150%',NULL,30,NULL,NULL,'end','on','1',0.00,NULL,0,0,0,0,0,0.00,0,0.000000,0.000000,0,0.00,100.00,'',0,0,'',0,0,2,0,0.00,0.00,0,0,0,1.0000000000,NULL,NULL,1,1,0,0,100.0000,0,'',1.00000000);
/*!40000 ALTER TABLE `hm2_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_umessages`
--

DROP TABLE IF EXISTS `hm2_umessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_umessages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `expiration` int(10) unsigned DEFAULT 0,
  `text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_umessages`
--

LOCK TABLES `hm2_umessages` WRITE;
/*!40000 ALTER TABLE `hm2_umessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_umessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_user_access_log`
--

DROP TABLE IF EXISTS `hm2_user_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_user_access_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `ip` varchar(50) DEFAULT '',
  `user_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `d_idx` (`date`),
  KEY `ip_idx` (`ip`),
  KEY `idip` (`id`,`date`,`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_user_access_log`
--

LOCK TABLES `hm2_user_access_log` WRITE;
/*!40000 ALTER TABLE `hm2_user_access_log` DISABLE KEYS */;
INSERT INTO `hm2_user_access_log` (`id`, `user_id`, `date`, `ip`, `user_agent`) VALUES (1,1,'2020-12-07 11:07:58','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'),(2,1,'2020-12-07 12:20:25','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'),(3,1,'2020-12-07 19:32:55','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'),(4,1,'2020-12-07 19:45:21','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'),(5,2,'2020-12-08 10:29:42','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'),(6,3,'2020-12-08 23:49:44','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'),(7,1,'2020-12-08 23:51:04','154.28.188.199','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
/*!40000 ALTER TABLE `hm2_user_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_user_balances`
--

DROP TABLE IF EXISTS `hm2_user_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_user_balances` (
  `user_id` int(10) unsigned DEFAULT NULL,
  `ec` int(10) unsigned DEFAULT NULL,
  `amount` decimal(20,10) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  KEY `hi1` (`user_id`),
  KEY `hi2` (`user_id`,`ec`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_user_balances`
--

LOCK TABLES `hm2_user_balances` WRITE;
/*!40000 ALTER TABLE `hm2_user_balances` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_user_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_users`
--

DROP TABLE IF EXISTS `hm2_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `date_register` datetime DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `status` enum('on','off','suspended') DEFAULT NULL,
  `came_from` text NOT NULL,
  `ref` bigint(20) NOT NULL DEFAULT 0,
  `deposit_total` float(10,2) NOT NULL DEFAULT 0.00,
  `confirm_string` varchar(200) NOT NULL DEFAULT '',
  `password_confimation` varchar(200) NOT NULL DEFAULT '',
  `ip_reg` varchar(50) DEFAULT '',
  `last_access_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_access_ip` varchar(50) DEFAULT '',
  `stat_password` varchar(200) NOT NULL,
  `auto_withdraw` int(11) NOT NULL DEFAULT 1,
  `user_auto_pay_earning` int(11) NOT NULL,
  `admin_auto_pay_earning` int(11) NOT NULL,
  `pswd` varchar(50) NOT NULL,
  `hid` varchar(50) NOT NULL,
  `l_e_t` datetime NOT NULL DEFAULT '2004-01-01 00:00:00',
  `activation_code` varchar(50) NOT NULL,
  `bf_counter` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `transaction_code` varchar(255) DEFAULT NULL,
  `ac` text NOT NULL,
  `accounts` text DEFAULT NULL,
  `sq` text NOT NULL,
  `sa` text NOT NULL,
  `reg_fee` decimal(20,10) NOT NULL DEFAULT 0.0000000000,
  `home_phone` varchar(200) NOT NULL DEFAULT '',
  `cell_phone` varchar(200) NOT NULL DEFAULT '',
  `work_phone` varchar(200) NOT NULL DEFAULT '',
  `verify` int(11) NOT NULL DEFAULT 0,
  `pax_utype` int(11) NOT NULL DEFAULT 0,
  `gfst_phone` varchar(20) NOT NULL DEFAULT '',
  `add_fields` text DEFAULT NULL,
  `admin_desc` text DEFAULT NULL,
  `max_daily_withdraw` decimal(20,10) DEFAULT 0.0000000000,
  `group_id` bigint(20) NOT NULL DEFAULT 0,
  `tfa_flag` tinyint(1) DEFAULT NULL,
  `demo_acc` tinyint(1) NOT NULL DEFAULT 0,
  `mult` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `mult_last_check` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hi1` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_users`
--

LOCK TABLES `hm2_users` WRITE;
/*!40000 ALTER TABLE `hm2_users` DISABLE KEYS */;
INSERT INTO `hm2_users` (`id`, `name`, `username`, `password`, `date_register`, `email`, `status`, `came_from`, `ref`, `deposit_total`, `confirm_string`, `password_confimation`, `ip_reg`, `last_access_time`, `last_access_ip`, `stat_password`, `auto_withdraw`, `user_auto_pay_earning`, `admin_auto_pay_earning`, `pswd`, `hid`, `l_e_t`, `activation_code`, `bf_counter`, `address`, `city`, `state`, `zip`, `country`, `transaction_code`, `ac`, `accounts`, `sq`, `sa`, `reg_fee`, `home_phone`, `cell_phone`, `work_phone`, `verify`, `pax_utype`, `gfst_phone`, `add_fields`, `admin_desc`, `max_daily_withdraw`, `group_id`, `tfa_flag`, `demo_acc`, `mult`, `mult_last_check`) VALUES (1,'admin name','admin','209a462a7fbfdebadd9d439c4c360e4f',NULL,'arinzeezeozue@gmail.com','on',' ',0,0.00,'','11d0a2eb8be116c8e6972b26cf746d3b','','2020-12-09 00:02:44','154.28.188.199','',1,0,0,'','000526DF950D60D6D62C2F08533F4B','2020-12-07 12:33:42','',0,NULL,NULL,NULL,NULL,NULL,NULL,'557e047f3f430f090e1a545c4d5554356928406108300e7c0967205946515654555d1b0b447b07750a615726402150311b52475f434b554b1b0b447b0e7b12275a3055265f2020120e430e0d0a1b5c5d56285a630b300971077e112436595b4a515d4a5c564a422476265d225a2f1a275c28660b460a050a0a1b555144356923422c44305136117e370a07030e1a514b505e4d24533b552c4936510454282559591e57575d1b02430d760c635c2240376b2d43677f430f02070212584b59593b53244a265c394121732229515c5c1a5b5f541b0b447b057b12335a2d167f407f740a17120f4b0a00031243285b244337522e4466082c7e000e4d',NULL,'','',0.0000000000,'','','',0,0,'',NULL,NULL,0.0000000000,0,NULL,0,0,NULL),(2,'Arinze Eze','masterari','827ccb0eea8a706c4c34a16891f84e7b','2020-12-08 10:29:01','naijacrystal@yahoo.com','on','',0,0.00,'','','154.28.188.199','2020-12-08 10:31:34','154.28.188.199','',1,0,0,'','2CD915F3346499FFCFFD7D9BE368CA','2020-12-08 10:29:48','',0,'','','','','','','','N;','Who','Me',0.0000000000,'','','',0,0,'','a:4:{s:27:\"account_update_confirmation\";i:0;s:18:\"account_statements\";i:0;s:29:\"use_transaction_code_withdraw\";i:0;s:33:\"use_transaction_code_edit_account\";i:0;}','',0.0000000000,0,NULL,0,0,NULL),(3,'Arinze Eze','mk','827ccb0eea8a706c4c34a16891f84e7b','2020-12-08 23:49:13','arinzeezeozu@gmail.com','on','',0,0.00,'','','154.28.188.199','2020-12-08 23:50:24','154.28.188.199','',1,0,0,'','391C4FFED06E59392FC65E3DD92C1D','2020-12-08 23:49:46','',0,'','','','','','1234','','N;','Who','Me',0.0000000000,'','','',0,0,'','a:4:{s:27:\"account_update_confirmation\";i:0;s:18:\"account_statements\";i:0;s:29:\"use_transaction_code_withdraw\";i:0;s:33:\"use_transaction_code_edit_account\";i:0;}','',0.0000000000,0,NULL,0,0,NULL);
/*!40000 ALTER TABLE `hm2_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_wires`
--

DROP TABLE IF EXISTS `hm2_wires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_wires` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `pname` varchar(250) NOT NULL,
  `paddress` varchar(250) NOT NULL,
  `pzip` varchar(250) NOT NULL,
  `pcity` varchar(250) NOT NULL,
  `pstate` varchar(250) NOT NULL,
  `pcountry` varchar(250) NOT NULL,
  `bname` varchar(250) NOT NULL,
  `baddress` varchar(250) NOT NULL,
  `bzip` varchar(250) NOT NULL,
  `bcity` varchar(250) NOT NULL,
  `bstate` varchar(250) NOT NULL,
  `bcountry` varchar(250) NOT NULL,
  `baccount` varchar(250) NOT NULL,
  `biban` varchar(250) NOT NULL,
  `bswift` varchar(250) NOT NULL,
  `amount` float(10,5) DEFAULT NULL,
  `type_id` bigint(20) DEFAULT NULL,
  `wire_date` datetime NOT NULL,
  `compound` float(10,5) DEFAULT NULL,
  `status` enum('new','problem','processed') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_wires`
--

LOCK TABLES `hm2_wires` WRITE;
/*!40000 ALTER TABLE `hm2_wires` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_wires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hm2_withdrawal_proofs`
--

DROP TABLE IF EXISTS `hm2_withdrawal_proofs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hm2_withdrawal_proofs` (
  `id` bigint(20) DEFAULT NULL,
  `pdate` datetime NOT NULL,
  `approved` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hm2_withdrawal_proofs`
--

LOCK TABLES `hm2_withdrawal_proofs` WRITE;
/*!40000 ALTER TABLE `hm2_withdrawal_proofs` DISABLE KEYS */;
/*!40000 ALTER TABLE `hm2_withdrawal_proofs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'stjohqse_hybrid'
--

--
-- Dumping routines for database 'stjohqse_hybrid'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-05  9:52:11
